import {isSpaceRoute,spaceFor,teamForm} from './spaces.mjs';
import { emptyWorkspace, validateWorkspace, uid, stamp, templates, recordStates, moveToTrash, restoreFromTrash, parseMetrics, metricComparison, exportLatex } from './core.mjs';
import { api, request, isDesktop, chooseFiles, saveText, saveAttachment, external } from './bridge.mjs';
import { shell, page as pageView, inspector as inspectorView } from './views.mjs';
import * as forms from './forms.mjs';
import { icon as i } from './icons.mjs';
import { escape as e, button as b, empty, markdown } from './ui.mjs';
import { renderPdf, cancelPdfRender, pdfMetadata, extractPdfText } from './reader.mjs';

let data = emptyWorkspace(), ready = false, savedRevision = -1, saving = null, saveTimer, mirrorTimer, savedMirror = null;
let lastPageKey = '', lastFrameKey = '', lastInspectorSignature = '', modalCloseTimer = null, searchTimer = null, chatScrollFrame = 0, searchComposing = false;
const ui = { projectId:null,projectSessions:{},projectQuery:'',projectFilter:'all',projectSort:'updated',projectView:'grid',tabs:['home'], active:'home', expanded:new Set(), panel:null, scrolls:{}, researchView:'board', recordFilter:'全部', recordQuery:'', paperStatus:'全部', paperScope:'all', paperQuery:'', paperSelection:new Set(), showIgnored:false, runView:'runs', runQuery:'', runSelection:new Set(), metric:'', comparisons:{}, repos:{}, pdfPage:1, pdfZoom:'fit', selection:'', editorPreview:false, saveState:'saved', settingsTab:'general', models:[], sessionIds:{}, drafts:{}, requests:{}, output:null, importing:false, refreshing:false, feedError:'', downloading:null, restoreFocus:null, suspended:null, suspendedFocus:null, chatScrollReset:false };
const $ = selector => document.querySelector(selector);
const project = id => data.projects.find(x=>x.id===id);
const records = pid => data.records.filter(x=>x.project===pid);
const runs = pid => data.runs.filter(x=>x.project===pid);
function info(key=ui.active) {
  const [type,id] = key.split('/'); let item, pid;
  if(type==='record'){item=data.records.find(x=>x.id===id);pid=item?.project;}
  if(type==='paper'){item=data.papers.find(x=>x.id===id);pid=ui.projectId||(item?.projects?.includes(ui.paperScope)?ui.paperScope:item?.projects?.[0]);}
  if(type==='run'){item=data.runs.find(x=>x.id===id);pid=item?.project;}
  if(['project','research','runs','chat','compare'].includes(type))pid=id;
  if(['library','inbox','trash'].includes(type))pid=ui.projectId;
  const pr=project(pid);
  const names={home:['我的工作空间','folder'],profile:['个人信息','user'],team:[data.teams.find(t=>t.id===id)?.name,'team'],teaminfo:[data.teams.find(t=>t.id===id)?'团队信息':null,'team'],library:['文献库','book'],inbox:['收件箱','inbox'],trash:['回收站','trash'],archived:['已归档项目','folder'],project:[pr?.name,'folder'],research:['研究工作区','board'],runs:['实验与代码','flask'],chat:['项目助手','chat'],compare:['实验比较','compare'],record:[item?.title,'file'],paper:[item?.title,'book'],run:[item?.name,'flask']};
  const label=names[type]; const valid=Boolean(label && label[0] && (!['project','research','runs','chat','compare'].includes(type)||pr));
  return {key,type,id,item,pid,pr,title:label?.[0]||'内容已移除',icon:label?.[1]||'file',valid};
}
function session(pid) {
  let value=data.sessions.find(s=>s.id===ui.sessionIds[pid]&&s.project===pid)||data.sessions.find(s=>s.project===pid);
  if(!value&&project(pid)){value={id:uid(),project:pid,title:'新的对话',messages:[],context:[],createdAt:stamp(),updatedAt:stamp()};data.sessions.push(value);touch();}
  if(value)ui.sessionIds[pid]=value.id;
  return value;
}
const context={get data(){return data},ui,get route(){return info()},info,project,records,runs,session,desktop:isDesktop};
function notify(text,action,label='撤销') { const toast=$('#toast');toast.innerHTML=`<div class="toast-message"><span>${e(text)}</span>${action?`<button data-action="${action.action}" data-id="${e(action.id||'')}">${label}</button>`:''}</div>`;toast.classList.remove('toast-pop','toast-dismiss');void toast.offsetWidth;toast.classList.add('toast-pop');clearTimeout(notify.timer);notify.timer=setTimeout(()=>{toast.classList.remove('toast-pop');toast.classList.add('toast-dismiss');setTimeout(()=>{if(toast.classList.contains('toast-dismiss')){toast.replaceChildren();toast.classList.remove('toast-dismiss');}},180);},action?6500:3500); }
function log(text){data.activity.unshift({id:uid(),text,at:stamp()});data.activity=data.activity.slice(0,60);}
function touch(message) {
  if(!ready)return;
  data.revision=(data.revision||0)+1;data.updatedAt=stamp();if(message)log(message);
  clearTimeout(mirrorTimer);mirrorTimer=setTimeout(()=>{try{localStorage.setItem('scientify-workspace-cache-v3',JSON.stringify(data));}catch{}},500);
  ui.saveState='pending';paintSave();clearTimeout(saveTimer);saveTimer=setTimeout(()=>flush().catch(()=>{}),350);
}
async function flush() {
  clearTimeout(saveTimer);if(!ready)return;
  if(saving){await saving;if(data.revision>savedRevision)return flush();return;}
  if(data.revision===savedRevision){ui.saveState='saved';paintSave();return;}
  const snapshot=structuredClone(data);ui.saveState='saving';paintSave();
  saving=api('save',snapshot).then(()=>{savedRevision=snapshot.revision;ui.saveState='saved';}).catch(err=>{ui.saveState='error';ui.saveError=err.message;throw err;}).finally(()=>{saving=null;paintSave();});
  await saving;if(data.revision>savedRevision)return flush();
}
function paintSave(){const text=({saved:'已保存',pending:'等待保存',saving:'正在保存…',error:'保存失败'})[ui.saveState];document.querySelectorAll('[data-save-label]').forEach(el=>{el.textContent=text;el.classList.toggle('save-error',ui.saveState==='error')});if($('#statusbar'))$('#statusbar').innerHTML=`<span class="row">${i('folder',true)}本地工作区</span><span class="save-status ${ui.saveState==='error'?'save-error':''}">${ui.saveState==='saving'?'<span class="spinner tiny-spinner"></span>':''}${text}</span>${ui.saveState==='error'?b('重试保存','retry-save',{flat:true,small:true}):''}<span class="spacer"></span>`;}
function persistNavigation(){if(ui.projectId)ui.projectSessions[ui.projectId]={tabs:[...ui.tabs],active:ui.active,panel:ui.panel};data.navigation={tabs:ui.tabs,active:ui.active,expanded:[...ui.expanded],panel:ui.panel,comparisons:ui.comparisons,projectSessions:ui.projectSessions,sessionIds:{...ui.sessionIds}};touch();}
function applyTheme(){document.body.classList.toggle('dark',data.settings.theme==='dark'||(data.settings.theme==='system'&&matchMedia('(prefers-color-scheme: dark)').matches));}
function enhanceTooltips(root=document){root.querySelectorAll?.('button[aria-label]:not([title])').forEach(el=>el.title=el.getAttribute('aria-label'));}
function animateSurface(el,className='surface-enter'){if(!el)return;el.classList.remove(className);void el.offsetWidth;el.classList.add(className);const done=()=>el.classList.remove(className);el.addEventListener('animationend',done,{once:true});setTimeout(done,420);}
function renderTitle(){const r=info();$('#titlebar').innerHTML=`<div class="titlebar-brand"><span class="brand-icon">S</span>Scientify</div><span class="titlebar-title">${e(r.pr?.name||(r.type==='team'||r.type==='teaminfo'?data.teams.find(t=>t.id===r.id)?.name:'我的工作空间'))}</span>${isDesktop?`<div class="window-controls">${[['minimize','min','最小化'],['maximize','max','最大化或还原'],['close','close','关闭窗口']].map(([a,icon,label])=>`<button data-action="window" data-value="${a}" class="${a==='close'?'close':''}" aria-label="${label}">${i(icon)}</button>`).join('')}</div>`:'<span class="titlebar-spacer"></span>'}`;enhanceTooltips($('#titlebar'));}
function prepareTabs(){
  const tabs=$('#tabs');
  if(!tabs)return;
  tabs.setAttribute('role','tablist');
  tabs.setAttribute('aria-label','打开的页面');
  tabs.setAttribute('aria-orientation','horizontal');
  const buttons=[...tabs.querySelectorAll('.tab-main[role="tab"]')];
  buttons.forEach((button,index)=>{
    button.tabIndex=button.getAttribute('aria-selected')==='true'?0:-1;
    button.dataset.tabIndex=String(index);
    button.closest('.tab')?.setAttribute('role','presentation');
  });
}
function focusTab(key,activate=false){
  const button=[...document.querySelectorAll('#tabs .tab-main[role="tab"]')].find(el=>el.dataset.key===key);
  if(!button)return;
  if(activate&&button.dataset.key!==ui.active){button.click();return;}
  button.focus({preventScroll:true});
  button.closest('.tab')?.scrollIntoView({block:'nearest',inline:'nearest'});
}
function drawFrame(){const frameKey=info().key,entering=frameKey!==lastFrameKey;lastFrameKey=frameKey;document.body.classList.toggle('space-mode',isSpaceRoute(info().type));const html=shell(context);$('#sidebar').innerHTML=html.sidebar;$('#tabs').innerHTML=html.tabs;prepareTabs();$('#toolbar').innerHTML=html.toolbar;renderTitle();if(entering){animateSurface($('#sidebar'));animateSurface($('#toolbar'));}enhanceTooltips($('#sidebar'));enhanceTooltips($('#tabs'));enhanceTooltips($('#toolbar'));paintSave();}
function captureScroll(selector){return [...document.querySelectorAll(selector)].map(el=>({top:el.scrollTop,nearBottom:el.scrollHeight-el.scrollTop-el.clientHeight<96}));}
const pendingChatRestore={chat:null,assistant:null,forceChat:false,forceAssistant:false};
function scheduleChatRestore(kind,state,force=false){
  pendingChatRestore[kind]=state||[];
  pendingChatRestore[kind==='chat'?'forceChat':'forceAssistant']=force;
  cancelAnimationFrame(chatScrollFrame);
  chatScrollFrame=requestAnimationFrame(()=>{
    const restore=(selector,snapshot,shouldForce)=>[...document.querySelectorAll(selector)].forEach((el,index)=>{
      const saved=snapshot?.[index];
      if(shouldForce||!saved||saved.nearBottom)el.scrollTop=el.scrollHeight;
      else el.scrollTop=Math.min(saved.top,Math.max(0,el.scrollHeight-el.clientHeight));
    });
    restore('.chat-scroll',pendingChatRestore.chat,pendingChatRestore.forceChat);
    restore('.assistant-scroll',pendingChatRestore.assistant,pendingChatRestore.forceAssistant);
    pendingChatRestore.chat=pendingChatRestore.assistant=null;
    pendingChatRestore.forceChat=pendingChatRestore.forceAssistant=false;
  });
}
function drawPage(preserve=true){const page=$('#page'),routeKey=info().key,entering=routeKey!==lastPageKey,chatState=captureScroll('.chat-scroll');lastPageKey=routeKey;const pos=preserve?page.scrollTop:0;cancelPdfRender();page.innerHTML=pageView(context);page.scrollTop=pos;if(entering)animateSurface(page);enhanceTooltips(page);enhanceBoardCards(page);if(info().type==='record')sizeEditor();if(info().type==='paper'&&info().item.attachment)void drawPdf();if(info().type==='chat'){scheduleChatRestore('chat',chatState,entering||ui.chatScrollReset);ui.chatScrollReset=false;}paintSave();}
function drawInspector(){const inspector=$('#inspector'),assistantState=captureScroll('.assistant-scroll'),html=inspectorView(context),signature=`${info().key}|${ui.panel}|${html?'open':'closed'}`,entering=signature!==lastInspectorSignature;lastInspectorSignature=signature;inspector.classList.toggle('hidden',!html);inspector.innerHTML=html;if(html&&entering)animateSurface(inspector);enhanceTooltips(inspector);if(html)scheduleChatRestore('assistant',assistantState,entering||ui.chatScrollReset);paintSave();}
function render(){applyTheme();drawFrame();drawPage();drawInspector();}
function sizeEditor(){
  const el=$('#record-body');
  if(!el)return;
  // Keep long notes inside the page viewport so the editor does not make the
  // entire workspace grow without bound while typing.
  const top=Math.max(0,el.getBoundingClientRect().top);
  // Keep the normal editing area usable while still capping very long notes.
  // The lower bound matches the base textarea min-height so the two rules do
  // not fight each other in a short window.
  const maxHeight=Math.max(460,Math.min(680,Math.floor(innerHeight-top-72)));
  el.style.maxHeight=maxHeight+'px';
  el.style.height='auto';
  const contentHeight=Math.max(460,el.scrollHeight);
  const nextHeight=Math.min(contentHeight,maxHeight);
  el.style.height=nextHeight+'px';
  el.style.overflowY=contentHeight>maxHeight?'auto':'hidden';
}
function chatNearBottom(selector='.chat-scroll,.assistant-scroll'){const nodes=[...document.querySelectorAll(selector)];return !nodes.length||nodes.every(el=>el.scrollHeight-el.scrollTop-el.clientHeight<96);}
function scrollChat(force=false){scheduleChatRestore('chat',captureScroll('.chat-scroll'),force);scheduleChatRestore('assistant',captureScroll('.assistant-scroll'),force);}
function guardProfile(){const form=$('form[data-form="profile"]');if(form?.dataset.dirty==='true'){notify('请保存个人信息，或点击「取消修改」后离开。');return true;}return false;}
function openSpace(key='home'){
  if(guardProfile())return;
  if(!info(key).valid){notify('这个空间暂时不可用。');return;}
  if(ui.projectId)ui.projectSessions[ui.projectId]={tabs:[...ui.tabs],active:ui.active,panel:ui.panel};
  closeMenu();ui.projectId=null;ui.active=key;ui.tabs=[key];ui.panel=null;ui.paperScope='all';ui.paperSelection.clear();ui.runSelection.clear();
  ui.projectQuery='';ui.projectFilter='all';persistNavigation();render();$('#page').scrollTop=0;
}
function enterProject(id,key){
  if(guardProfile())return;const p=project(id);if(!p){notify('项目不存在。');return;}
  if(ui.projectId&&ui.projectId!==id)ui.projectSessions[ui.projectId]={tabs:[...ui.tabs],active:ui.active,panel:ui.panel};
  const remembered=ui.projectSessions[id];ui.projectId=id;ui.paperScope=id;ui.paperQuery='';ui.paperStatus='全部';ui.recordQuery='';ui.recordFilter='全部';ui.runQuery='';ui.runSelection.clear();ui.paperSelection.clear();
  ui.tabs=(remembered?.tabs||[]).filter(k=>{const x=info(k);return x.valid&&!isSpaceRoute(x.type)&&(x.type!=='paper'||x.item.projects.includes(id))&&(x.pid===id||x.type==='trash');});
  const base='project/'+id;if(!ui.tabs.includes(base))ui.tabs.unshift(base);
  ui.active=base;ui.panel=null;p.lastOpenedAt=stamp();
  const target=key||(remembered?.active&&ui.tabs.includes(remembered.active)?remembered.active:base);
  go(target);
}
function go(key,{recent=true}={}){
  if(isSpaceRoute(key.split('/')[0]))return openSpace(key);
  const target=info(key);
  if(target.pid&&target.pid!==ui.projectId){enterProject(target.pid,key);return;}
  if(!info(key).valid){notify('这条内容已被移除。');return;}const fromTab=document.activeElement?.closest('#tabs .tab-main');closeMenu();ui.scrolls[ui.active]=$('#page').scrollTop;
  const prev=info();ui.active=key;if(!ui.tabs.includes(key))ui.tabs.push(key);const r=info();
  if(r.pid)ui.expanded.add(r.pid);if(r.type==='paper'){ui.panel='notes';ui.pdfPage=r.item.lastPage||1;ui.pdfZoom='fit';ui.selection='';}else if(ui.panel==='notes')ui.panel=null;
  if(r.type!=='record'||prev.id!==r.id)ui.editorPreview=false;
  if(recent&&['record','paper','run'].includes(r.type)){data.recent=[{key,at:stamp()},...data.recent.filter(x=>x.key!==key)].slice(0,20);}
  persistNavigation();render();$('#page').scrollTop=ui.scrolls[key]||0;requestAnimationFrame(()=>{if(fromTab)focusTab(key);else $('#tabs .tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});});
}
function closeTab(key){
  if(!ui.projectId||isSpaceRoute(info(key).type)||key==='project/'+ui.projectId)return;
  const index=ui.tabs.indexOf(key),wasActive=ui.active===key;
  // Preserve focus on the active tab when closing a background tab. When the
  // active tab closes, move focus to the nearest surviving tab.
  const focusKey=wasActive?(ui.tabs[index-1]||ui.tabs[index+1]||'project/'+ui.projectId):ui.active;
  ui.scrolls[ui.active]=$('#page').scrollTop;
  ui.tabs=ui.tabs.filter(x=>x!==key);
  const fallback='project/'+ui.projectId;
  if(!ui.tabs.includes(fallback))ui.tabs.unshift(fallback);
  if(wasActive)ui.active=ui.tabs[Math.max(0,index-1)]||ui.tabs[index]||fallback;
  if(!info(ui.active).valid)ui.active=fallback;
  persistNavigation();render();$('#page').scrollTop=ui.scrolls[ui.active]||0;
  requestAnimationFrame(()=>focusTab(info(focusKey).valid?focusKey:ui.active));
}
function repairTabs(){ui.tabs=ui.tabs.filter(k=>info(k).valid);const base=ui.projectId?'project/'+ui.projectId:'home';if(!ui.tabs.includes(base))ui.tabs.unshift(base);if(!info(ui.active).valid)ui.active=base;persistNavigation();}

function showModal(spec){closeMenu();clearTimeout(modalCloseTimer);if(!$('.modal'))ui.restoreFocus=document.activeElement;$('#modal-root').innerHTML=`<div class="modal-backdrop"><section class="modal ${spec.wide?'wide':''}" role="dialog" aria-modal="true" aria-labelledby="modal-title"><header class="modal-header"><h2 id="modal-title">${e(spec.title)}</h2><button class="icon-btn" data-action="close-modal" aria-label="关闭对话框">${i('close')}</button></header>${spec.raw?spec.body:`<div class="modal-body">${spec.body}</div>`}</section></div>`;$('#desktop-app').inert=true;enhanceTooltips($('#modal-root'));requestAnimationFrame(()=>($('.modal [autofocus]')||$('.modal input:not([type="checkbox"]):not([type="hidden"]):not([type="radio"])')||$('.modal button'))?.focus());}
function closeModal(force=false){const form=$('.modal form')||$('.modal');if(!force&&form?.dataset.dirty==='true'&&!ui.suspended){const restoreFocus=ui.restoreFocus;ui.suspended=$('#modal-root').firstElementChild;ui.suspendedFocus=focusDescriptor(document.activeElement);ui.suspended.remove();showModal({title:'放弃尚未保存的更改？',body:`<p class="small muted">已经填写的内容还没有保存。</p><div class="modal-footer">${b('继续编辑','keep-editing')}${b('放弃更改','discard-edit',{primary:true})}</div>`});ui.restoreFocus=restoreFocus;return;}const root=$('#modal-root'),node=root.firstElementChild;if(!node){$('#desktop-app').inert=false;ui.suspended=null;return;}node.classList.add('modal-closing');clearTimeout(modalCloseTimer);const delay=matchMedia('(prefers-reduced-motion: reduce)').matches?0:180;modalCloseTimer=setTimeout(()=>{if(root.firstElementChild!==node)return;root.replaceChildren();$('#desktop-app').inert=false;ui.suspended=null;if(ui.restoreFocus?.isConnected)ui.restoreFocus.focus();},delay);}
function closeMenu(){$('#menu-root').replaceChildren();}
function menu(anchor,items){closeMenu();const rect=anchor.getBoundingClientRect();$('#menu-root').innerHTML=`<div class="context-menu" role="menu">${items.map(item=>item.separator?'<div class="menu-separator"></div>':`<button role="menuitem" class="${item.danger?'danger':''}" data-action="${item.action}" ${item.id?`data-id="${e(item.id)}"`:''} ${item.value!==undefined?`data-value="${e(item.value)}"`:''}>${item.icon?i(item.icon,true):''}${e(item.label)}</button>`).join('')}</div>`;const popup=$('.context-menu');popup.style.left=Math.max(8,Math.min(innerWidth-popup.offsetWidth-12,rect.right-popup.offsetWidth))+'px';popup.style.top=Math.max(8,Math.min(innerHeight-popup.offsetHeight-28,rect.bottom+5))+'px';enhanceTooltips(popup);popup.querySelector('button')?.focus();ui.menuFocus=anchor;}
function formError(form,message){const node=form.querySelector('.form-error');if(node){node.textContent=message;node.scrollIntoView({block:'nearest'});}else notify(message);}
async function busyButton(button,operation){if(button?.disabled)return;const content=button?.innerHTML,width=button?.getBoundingClientRect().width;if(button){button.disabled=true;button.classList.add('is-busy');button.setAttribute('aria-busy','true');if(width)button.style.minWidth=`${width}px`;button.innerHTML='<span class="spinner button-spinner"></span><span>处理中…</span>';}try{return await operation();}finally{if(button?.isConnected){button.disabled=false;button.classList.remove('is-busy');button.removeAttribute('aria-busy');button.style.minWidth='';button.innerHTML=content;enhanceTooltips(button.parentElement||document);}}}
async function drawPdf(){const r=info(),host=$('#pdf-host');if(!r.item?.attachment||!host)return;try{await renderPdf(r.item.attachment.id,ui.pdfPage,ui.pdfZoom,host,details=>{if(info().key!==r.key)return;ui.pdfPage=details.page;const changed=r.item.pages!==details.pages||r.item.lastPage!==details.page;r.item.pages=details.pages;r.item.lastPage=details.page;if(changed)touch();$('#pdf-pages').textContent=details.pages;$('#pdf-page-number').value=details.page;document.querySelector('[data-action="pdf-prev"]').disabled=details.page<=1;document.querySelector('[data-action="pdf-next"]').disabled=details.page>=details.pages;});}catch(err){if(host.isConnected)host.innerHTML=empty('file','无法打开这份 PDF','文件可能损坏或需要密码。可以重新关联 PDF，原有笔记会保留。',b('重新关联','attach-paper',{id:r.id})+b('保存文件','save-paper-file',{id:r.id}));}}
async function importPDF(targetId=null){if(ui.importing)return;ui.importing=true;const r=info();if(r.type==='library')drawPage();else drawFrame();const result=await chooseFiles(targetId?'pdf-single':'pdf').catch(err=>({files:[],errors:[err.message]}));const failures=[...(result.errors||[])];let added=0,first=null;
  for(const attachment of result.files){try{const meta=await pdfMetadata(attachment.id);const existing=data.papers.find(p=>p.attachment?.digest&&p.attachment.digest===attachment.digest);if(existing&&!targetId){first=existing;continue;}let paper=targetId?data.papers.find(p=>p.id===targetId):null;if(paper){paper.attachment=attachment;paper.pages=meta.pages;paper.lastPage=1;targetId=null;}else{paper={id:uid(),title:meta.title||attachment.name.replace(/\.pdf$/i,''),authors:meta.authors,published:'',source:'本地 PDF',abstract:'',url:'',tags:[],projects:r.pid?[r.pid]:ui.paperScope!=='all'?[ui.paperScope]:[],status:'未读',library:true,note:'',quotes:[],attachment,pages:meta.pages,createdAt:stamp(),updatedAt:stamp()};data.papers.push(paper);}first||=paper;added++;}catch(err){failures.push(attachment.name+'：无法读取 PDF。');}}
  ui.importing=false;if(added)touch('导入了 '+added+' 篇文献');render();if(first&&result.files.length===1)go('paper/'+first.id);if(failures.length)notify(failures.join(' '));else if(added)notify('已导入 '+added+' 篇文献');else if(first)notify('这份 PDF 已在文献库中。');
}
function trash(collection,id){const routeBefore=info(),item=moveToTrash(data,collection,id);if(!item)return;if(collection==='sessions'){const pending=ui.requests[id];if(pending)void api('cancelChat',pending.id);if(routeBefore.pid&&ui.sessionIds[routeBefore.pid]===id){delete ui.sessionIds[routeBefore.pid];ui.chatScrollReset=true;}}
  touch('移除了「'+(item.value.title||item.value.name)+'」');repairTabs();render();notify('已移至回收站',{action:'restore',id:item.id});}
function showNewRecord(options={}){if(!data.projects.some(p=>!p.archived)){ui.pendingRecord=options;showModal(forms.projectForm(context));return;}showModal(forms.recordForm(context,options));}
function sourceModal(){const output=ui.output;showModal({title:'导出研究内容',wide:true,body:`<div class="output-topline"><div><strong>${e(output.title)}</strong><span>${output.records.length} 条记录</span></div>${b('保存 Markdown','save-markdown',{small:true})}</div><label class="label" for="latex-source">LaTeX 源码</label><textarea id="latex-source" class="field source-editor" aria-label="LaTeX 源码">${e(output.source)}</textarea><div id="compile-feedback"></div><div class="modal-footer">${b('返回选择','output')}${b('编译 PDF','compile',{icon:'play'})}${b('保存源码','save-source',{primary:true,icon:'download'})}</div>`});}
async function refreshRepo(){const r=info();if(!r.pr?.repo)return;ui.repos[r.pid]={loading:true};drawPage();try{const value=await api('repoStatus',r.pr.repo);ui.repos[r.pid]={value};}catch(err){ui.repos[r.pid]={error:err.message};}if(info().pid===r.pid&&info().type==='runs')drawPage();}
async function refreshFeed(){if(ui.refreshing)return;const rules=data.subscriptions.filter(s=>s.enabled);if(!rules.length){showModal(forms.subscriptions(context));return;}ui.refreshing=true;ui.feedError='';drawPage();let added=0;const errors=[];
  for(const [index,rule] of rules.entries()){if(index)await new Promise(resolve=>setTimeout(resolve,3000));try{const response=await api('papers',rule);for(const value of response.papers){const canonical=value.arxivId.replace(/v\d+$/,'');let existing=data.papers.find(p=>p.arxivId?.replace(/v\d+$/,'')===canonical);if(existing)continue;data.papers.push({id:uid(),...value,projects:[],tags:[],library:false,ignored:false,status:'未读',note:'',quotes:[],createdAt:stamp(),updatedAt:stamp()});added++;}rule.lastChecked=stamp();}catch(err){errors.push(rule.keyword+'：'+err.message);}}
  ui.refreshing=false;ui.feedError=errors.join(' ');touch();render();if(added)notify('收到了 '+added+' 篇新论文');else if(!errors.length)notify('已是最新论文');}
async function materialsFor(r,s){const keys=[...new Set([...s.context,...(['record','paper','run'].includes(r.type)?[r.key]:[])])];let body='项目：'+r.pr.name+'\n研究问题：'+(r.pr.question||'未填写')+'\n';for(const key of keys){const value=info(key);if(!value.valid||(value.type==='paper'?!value.item.projects.includes(r.pid):value.pid!==r.pid))continue;let text='';if(value.type==='record')text=value.item.body;if(value.type==='run')text=JSON.stringify(value.item);if(value.type==='paper'){text='摘要：'+(value.item.abstract||'')+'\n阅读笔记：'+(value.item.note||'');if(value.item.attachment)text+='\n全文摘录：'+await extractPdfText(value.item.attachment.id,35000);}body+='\n【'+value.title+'】\n'+text.slice(0,40000);if(body.length>70000)break;}return body.slice(0,70000);}
async function ask(text,retry=false){const r=info();if(!r.pid)return;const s=session(r.pid);if(ui.requests[s.id])return;if(!data.settings.model.model){ui.drafts[s.id]=text;ui.settingsTab='model';showModal(forms.settings(context));return;}text=text.trim();if(!text)return;
  if(!retry)s.messages.push({id:uid(),role:'user',text,at:stamp()});if(s.messages.length===1)s.title=text.slice(0,30);s.error='';s.updatedAt=stamp();ui.drafts[s.id]='';const id=uid();ui.requests[s.id]={id};touch();drawConversation();
  try{const material=await materialsFor(r,s);if(ui.requests[s.id]?.id!==id)return;const response=await api('chat',{...data.settings.model,requestId:id,messages:[{role:'system',content:'你是科研助手。基于用户提供的研究材料回答，明确区分材料事实与建议。引用材料标题，不编造论文、实验数据或结论。资料不足时明确说明。\n'+material},...s.messages.slice(-16).map(m=>({role:m.role,content:m.text}))]});if(ui.requests[s.id]?.id===id)s.messages.push({id:uid(),role:'assistant',text:response.content,at:stamp()});}
  catch(err){if(ui.requests[s.id]?.id===id)s.error=err.message;}
  finally{delete ui.requests[s.id];s.updatedAt=stamp();touch();drawConversation();}
}
function drawConversation(){if(info().type==='chat')drawPage();drawInspector();}
function searchModal(){showModal({title:'搜索工作区',wide:true,body:`<div class="search-modal"><label class="search-line">${i('search')}<input id="global-search" placeholder="搜索项目、文献、记录和实验…" aria-label="搜索工作区" autofocus><kbd>Esc</kbd></label><div id="search-results"></div></div>`});searchResults('');}
function searchResults(query){const q=query.trim().toLowerCase();const all=[...data.projects.filter(p=>!p.archived).map(x=>({key:'project/'+x.id,title:x.name,body:x.question,type:'项目'})),...data.papers.map(x=>({key:'paper/'+x.id,title:x.title,body:x.authors+' '+x.note,type:'文献'})),...data.records.map(x=>({key:'record/'+x.id,title:x.title,body:x.body,type:x.type})),...data.runs.map(x=>({key:'run/'+x.id,title:x.name,body:x.protocol+' '+x.conclusion,type:'实验'}))];const found=(q?all.filter(x=>(x.title+' '+x.body).toLowerCase().includes(q)):data.recent.map(x=>all.find(a=>a.key===x.key)).filter(Boolean)).slice(0,18);$('#search-results').innerHTML=found.length?`<div class="search-caption">${q?'搜索结果':'最近访问'}</div>${found.map(x=>`<button class="search-result" data-action="search-open" data-key="${x.key}">${i(info(x.key).icon)}<span>${e(x.title)}</span><small>${x.type}</small></button>`).join('')}`:`<div class="quiet-empty">${q?'没有找到相关内容。试试其他关键词。':'输入关键词，查找工作区中的内容。'}</div>`;}

function freshSession(pid){
  const existing=data.sessions.find(s=>s.project===pid&&!s.messages.length&&!s.context?.length&&(!s.title||s.title==='新的对话'));
  if(existing){ui.sessionIds[pid]=existing.id;ui.chatScrollReset=true;return existing;}
  const s={id:uid(),project:pid,title:'新的对话',messages:[],context:[],createdAt:stamp(),updatedAt:stamp()};
  data.sessions.unshift(s);ui.sessionIds[pid]=s.id;ui.chatScrollReset=true;touch();return s;
}
function recordText(x){return '## '+x.name+'\n\n评价设置：'+(x.protocol||'未填写')+'\n\n'+x.metrics.map(m=>m.name+'：'+(m.value??'缺失')+' '+m.unit).join('\n')+'\n\n### 结论\n\n'+x.conclusion+'\n\n### 参数\n\n'+(x.config||'未填写');}
function restoreEditor(){if(!ui.suspended)return;const focus=ui.suspendedFocus;$('#modal-root').replaceChildren(ui.suspended);ui.suspended=null;const target=focus?.id?document.getElementById(focus.id):focus?.name?$('.modal [name="'+CSS.escape(focus.name)+'"]'):null;const fallback=$('.modal input:not([type="hidden"]),.modal textarea,.modal select,.modal button');(target||fallback)?.focus();ui.suspendedFocus=null;}
function isSearchInput(el){return Boolean(el?.matches?.('#project-query,#paper-query,#record-query,#run-query,#global-search'));}
function searchPatchSelectors(){
  const type=info().type;
  if(type==='home'||type==='team')return {root:'.space-page',anchor:'.space-controls'};
  if(type==='profile'||type==='teaminfo'||type==='archived')return null;
  if(type==='library'||type==='inbox')return {root:'.page-inner.wide',anchor:'.library-toolbar'};
  if(type==='research')return {root:'.page-inner.wide',anchor:'.filters'};
  if(type==='runs')return {root:'.page-inner.wide',anchor:'.viewbar'};
  return null;
}
function patchSearchResults(){
  const selectors=searchPatchSelectors();
  if(!selectors)return false;
  const oldRoot=$('#page '+selectors.root),oldAnchor=oldRoot?.querySelector(selectors.anchor);
  if(!oldRoot||!oldAnchor)return false;
  const template=document.createElement('template');template.innerHTML=pageView(context);
  const nextRoot=template.content.querySelector(selectors.root),nextAnchor=nextRoot?.querySelector(selectors.anchor);
  if(!nextRoot||!nextAnchor)return false;
  const oldIndex=[...oldRoot.children].indexOf(oldAnchor),nextIndex=[...nextRoot.children].indexOf(nextAnchor);
  if(oldIndex<0||nextIndex<0)return false;
  [...oldRoot.children].slice(oldIndex+1).forEach(node=>node.remove());
  [...nextRoot.children].slice(nextIndex+1).forEach(node=>oldRoot.append(node.cloneNode(true)));
  enhanceTooltips(oldRoot);enhanceBoardCards(oldRoot);return true;
}
function refreshSearchInput(el){
  const id=el.id,start=el.selectionStart,end=el.selectionEnd,routeKey=info().key;
  clearTimeout(searchTimer);
  searchTimer=setTimeout(()=>{
    searchTimer=null;
    if(searchComposing||info().key!==routeKey||!document.getElementById(id))return;
    const focused=document.activeElement===el;
    if(!patchSearchResults()){
      drawPage();
      const next=$('#'+id);
      if(focused)next?.focus();
      try{next?.setSelectionRange(start,end);}catch{}
    }
  },120);
}
function focusDescriptor(el){
  if(!el||el===document.body||!el.isConnected)return null;
  const attrs=['id','data-task','data-paper-check','data-run-check','data-sub-toggle'];
  const descriptor={tag:el.tagName.toLowerCase(),selectionStart:el.selectionStart,selectionEnd:el.selectionEnd};
  for(const attr of attrs)if(el.hasAttribute(attr))descriptor[attr]=el.getAttribute(attr);
  if(el.name)descriptor.name=el.name;
  return descriptor;
}
function restoreFocusDescriptor(descriptor){
  if(!descriptor)return;
  let target=null;
  if(descriptor.id)target=document.getElementById(descriptor.id);
  if(!target)for(const attr of ['data-task','data-paper-check','data-run-check','data-sub-toggle'])if(descriptor[attr]!=null){target=document.querySelector(`[${attr}="${CSS.escape(descriptor[attr])}"]`);if(target)break;}
  if(!target&&descriptor.name)target=document.querySelector(`[name="${CSS.escape(descriptor.name)}"]`);
  if(!target)return;
  target.focus({preventScroll:true});
  if(descriptor.selectionStart!=null&&target.setSelectionRange)try{target.setSelectionRange(descriptor.selectionStart,descriptor.selectionEnd);}catch{}
}
function redrawPagePreservingFocus(preserve=true){const descriptor=focusDescriptor(document.activeElement);drawPage(preserve);requestAnimationFrame(()=>restoreFocusDescriptor(descriptor));}
function moveRecordStatus(id,status,{announce=true,focus=true}={}){
  const record=data.records.find(x=>x.id===id&&x.project===info().pid);
  if(!record||!recordStates.includes(status)||record.status===status)return false;
  record.status=status;record.updatedAt=stamp();touch();drawPage();
  if(focus)requestAnimationFrame(()=>document.querySelector(`[data-drag-record="${id}"]`)?.focus());
  if(announce)notify('已移至'+status);
  return true;
}
function enhanceBoardCards(root=document){
  root.querySelectorAll?.('[data-drag-record]').forEach(card=>{
    card.tabIndex=0;
    card.setAttribute('role','group');
    card.setAttribute('aria-grabbed','false');
    const record=data.records.find(x=>x.id===card.dataset.dragRecord);
    if(record)card.setAttribute('aria-label',`${record.title}，${record.status}。使用左右方向键移动`);
  });
}
async function onClick(event){
  const el=event.target.closest('[data-action]');
  if(!el){if(event.target.classList.contains('modal-backdrop')){if(ui.suspended)restoreEditor();else closeModal();}if(!event.target.closest('.context-menu'))closeMenu();return;}
  if(el.disabled)return;const {action:a,id,value:v,key}=el.dataset,r=info();
  if(a==='reset-profile'){const form=$('form[data-form="profile"]');if(form)form.dataset.dirty='false';drawPage();return;}
  if($('form[data-form="profile"]')?.dataset.dirty==='true'&&a!=='window'&&a!=='retry-save'){guardProfile();return;}
  if(a!=='project-menu'&&!a.endsWith('-menu'))closeMenu();
  switch(a){
    case 'space-open':openSpace(key);break;
    case 'enter-project':enterProject(id);break;
    case 'leave-project':openSpace(project(ui.projectId)?.space&&project(ui.projectId).space!=='personal'?'team/'+project(ui.projectId).space:'home');break;
    case 'space-filter':ui.projectFilter=v;drawPage(false);break;
    case 'space-view':ui.projectView=v;drawPage();break;
    case 'space-reset':ui.projectQuery='';ui.projectFilter='all';drawPage(false);break;
    case 'new-team':showModal(teamForm(context));break;
    case 'edit-team':showModal(teamForm(context,id));break;
    case 'open':if(key==='inbox'){ui.paperScope='all';ui.paperQuery='';}go(key);break;
    case 'search-open':closeModal(true);go(key);break;
    case 'close-tab':closeTab(key);break;
    case 'search':searchModal();break;
    case 'reload':location.reload();break;
    case 'retry-save':await flush();notify('已保存到本机');break;
    case 'window':await api('windowAction',v);break;
    case 'close-modal':if(ui.suspended)restoreEditor();else closeModal();break;
    case 'keep-editing':restoreEditor();break;
    case 'discard-edit':closeModal(true);break;
    case 'expand':ui.expanded.has(id)?ui.expanded.delete(id):ui.expanded.add(id);persistNavigation();drawFrame();break;
    case 'settings':showModal(forms.settings(context));break;
    case 'settings-tab':if($('.modal form')?.dataset.dirty==='true'){notify('请先保存连接设置，或取消编辑。');return;}ui.settingsTab=v;showModal(forms.settings(context));break;
    case 'model-settings':ui.settingsTab='model';showModal(forms.settings(context));break;
    case 'new-project':ui.pendingRecord=null;showModal(forms.projectForm(context));break;
    case 'edit-project':showModal(forms.projectForm(context,id||r.pid));break;
    case 'project-menu':{const p=project(id);menu(el,[{label:'编辑项目',action:'edit-project',id,icon:'edit'},{label:p.favorite?'取消收藏':'收藏项目',action:'favorite',id,icon:'star'},{separator:true},{label:p.archived?'恢复项目':'归档项目',action:p.archived?'unarchive':'archive',id,icon:'folder'}]);break;}
    case 'favorite':{const p=project(id);p.favorite=!p.favorite;touch();render();break;}
    case 'archive':project(id).archived=true;touch('归档了「'+project(id).name+'」');render();notify('项目已归档',{action:'unarchive',id});break;
    case 'unarchive':project(id).archived=false;touch();render();notify('项目已恢复');break;
    case 'choose-directory':{const result=await api('chooseDirectory');if(result.path){$('#field-path').value=result.path;$('#field-path').closest('form').dataset.dirty='true';}break;}
    case 'open-folder':await flush();await api('openDirectory',r.pr.path);break;
    case 'project-library':ui.paperScope=r.pid;ui.paperQuery='';ui.paperStatus='全部';go('library');break;
    case 'new-task':showModal(forms.simpleForm('添加待办','下一步要做什么','title','','task',r.pid));break;
    case 'remove-task':{const index=data.tasks.findIndex(t=>t.id===id);ui.removedTask=data.tasks.splice(index,1)[0];touch();drawPage();notify('已移除待办',{action:'undo-task',id});break;}
    case 'undo-task':if(ui.removedTask?.id===id){data.tasks.push(ui.removedTask);ui.removedTask=null;touch();drawPage();notify('待办已恢复');}break;
    case 'new-record':showNewRecord({status:el.dataset.status,type:ui.researchView==='docs'?'研究文档':undefined});break;
    case 'research-view':ui.researchView=v;drawPage();break;
    case 'record-filter':ui.recordFilter=v;drawPage();break;
    case 'record-menu':case 'object-menu':{const rid=id||r.id,record=data.records.find(x=>x.id===rid);menu(el,[{label:'重命名',action:'rename-record',id:rid,icon:'edit'},{label:'创建副本',action:'duplicate-record',id:rid,icon:'copy'},{label:'移至其他项目',action:'move-record',id:rid,icon:'folder'},...(record? [{separator:true},...recordStates.filter(status=>status!==record.status).map(status=>({label:'移至'+status,action:'move-record-status',id:rid,value:status,icon:'arrow'}))]:[]),{separator:true},{label:'移至回收站',action:'trash-record',id:rid,icon:'trash',danger:true}]);break;}
    case 'rename-record':showModal(forms.simpleForm('重命名记录','标题','title',data.records.find(x=>x.id===id).title,'rename-record',id));break;
    case 'duplicate-record':{const x=structuredClone(data.records.find(x=>x.id===id));x.id=uid();x.title+=' · 副本';x.createdAt=x.updatedAt=stamp();data.records.push(x);touch();go('record/'+x.id);break;}
    case 'move-record':{const x=data.records.find(x=>x.id===id);showModal({title:'移动研究记录',body:`<form data-form="move-record" data-id="${id}"><label class="label" for="move-project">目标项目</label><select class="field" name="project" id="move-project">${data.projects.filter(p=>!p.archived).map(p=>`<option value="${p.id}" ${p.id===x.project?'selected':''}>${e(p.name)}</option>`).join('')}</select><div class="form-error" role="alert"></div><div class="modal-footer">${b('取消','close-modal')}<button class="btn primary" type="submit">移动</button></div></form>`});break;}
    case 'trash-record':trash('records',id);break;
    case 'move-record-status':moveRecordStatus(id,v);break;
    case 'editor-preview':ui.editorPreview=!ui.editorPreview;drawPage();break;
    case 'format':{const edit=$('#record-body');if(!edit)return;const start=edit.selectionStart,end=edit.selectionEnd,text=edit.value.slice(start,end);const pair={heading:['## ',''],bold:['**','**'],italic:['*','*'],list:['- ',''],quote:['> ','']}[v];edit.setRangeText(pair[0]+text+pair[1],start,end,'select');edit.dispatchEvent(new Event('input',{bubbles:true}));edit.focus();break;}
    case 'add-paper':showModal(forms.paperForm(context));break;
    case 'edit-paper':showModal(forms.paperForm(context,id||r.id));break;
    case 'import-pdf':await importPDF();break;
    case 'attach-paper':await importPDF(id||r.id);break;
    case 'paper-filter':ui.paperStatus=v;ui.paperSelection.clear();drawPage();break;
    case 'show-ignored':ui.showIgnored=!ui.showIgnored;drawPage();break;
    case 'reset-paper-filters':ui.paperQuery='';ui.paperStatus='全部';ui.paperScope='all';drawPage();break;
    case 'clear-paper-selection':ui.paperSelection.clear();drawPage();break;
    case 'papers-read':for(const p of data.papers)if(ui.paperSelection.has(p.id)){p.status='已读';p.updatedAt=stamp();}ui.paperSelection.clear();touch();drawPage();break;
    case 'papers-trash':{const ids=[...ui.paperSelection];ui.bulkTrash=ids.map(id=>moveToTrash(data,'papers',id)).filter(Boolean).map(x=>x.id);ui.paperSelection.clear();touch();repairTabs();render();notify('已移除 '+ui.bulkTrash.length+' 篇文献',{action:'undo-bulk'});break;}
    case 'undo-bulk':for(const id of ui.bulkTrash||[])restoreFromTrash(data,id);ui.bulkTrash=[];touch();render();notify('文献已恢复');break;
    case 'paper-menu':{const x=data.papers.find(p=>p.id===id);menu(el,[{label:'编辑信息与项目归属',action:'edit-paper',id,icon:'edit'},...(x.url?[{label:'打开来源',action:'paper-source',id,icon:'arrow'}]:[]),...(x.attachment?[{label:'保存 PDF',action:'save-paper-file',id,icon:'download'}]:[]),...(x.library?[]:[{label:x.ignored?'恢复至收件箱':'忽略这篇论文',action:x.ignored?'unignore':'ignore',id}]),{separator:true},{label:'移至回收站',action:'trash-paper',id,icon:'trash',danger:true}]);break;}
    case 'collect':case 'unignore':case 'ignore':{const x=data.papers.find(p=>p.id===id);if(a==='collect'){x.library=true;x.ignored=false;}else x.ignored=a==='ignore';touch();render();notify(a==='collect'?'已加入文献库':a==='ignore'?'已忽略':'已恢复至收件箱');break;}
    case 'trash-paper':trash('papers',id);break;
    case 'paper-source':await external(data.papers.find(x=>x.id===id).url);break;
    case 'save-paper-file':await saveAttachment(data.papers.find(x=>x.id===id).attachment);break;
    case 'download-paper':{const x=data.papers.find(x=>x.id===id);ui.downloading=id;drawPage();try{x.attachment=await api('downloadPaper',x.arxivId);const meta=await pdfMetadata(x.attachment.id);x.pages=meta.pages;x.library=true;touch('下载了「'+x.title+'」');}finally{ui.downloading=null;render();}break;}
    case 'pdf-prev':case 'pdf-next':case 'quote-page':ui.pdfPage=a==='quote-page'?Number(v):ui.pdfPage+(a==='pdf-next'?1:-1);ui.pdfPage=Math.max(1,Math.min(r.item.pages||9999,ui.pdfPage));await drawPdf();break;
    case 'notes':ui.panel=ui.panel==='notes'?null:'notes';persistNavigation();drawFrame();drawInspector();break;
    case 'panel':case 'panel-ai':if(!r.pid)return;ui.panel=a==='panel'&&ui.panel==='ai'?null:'ai';persistNavigation();drawFrame();drawInspector();break;
    case 'close-panel':ui.panel=null;persistNavigation();drawFrame();drawInspector();break;
    case 'save-quote':if(ui.selection){r.item.quotes.push({id:uid(),text:ui.selection,page:ui.pdfPage,at:stamp()});ui.selection='';$('#pdf-selection-bar')?.classList.add('hidden');ui.panel='notes';touch();drawInspector();notify('摘录已保存');}break;
    case 'remove-quote':{const q=r.item.quotes.find(x=>x.id===id);ui.removedQuote={paper:r.id,value:q};r.item.quotes=r.item.quotes.filter(x=>x.id!==id);touch();drawInspector();notify('摘录已移除',{action:'undo-quote',id});break;}
    case 'undo-quote':{const q=ui.removedQuote,p=data.papers.find(x=>x.id===q?.paper);if(q?.value.id===id&&p){p.quotes.push(q.value);ui.removedQuote=null;touch();drawInspector();notify('摘录已恢复');}break;}
    case 'quote-ai':if(!r.pid){notify('请先将文献加入项目，再与项目助手讨论。');showModal(forms.paperForm(context,r.id));return;}ui.panel='ai';drawInspector();await ask('请解释这段原文：\n'+ui.selection);break;
    case 'paper-idea':showNewRecord({title:'关于「'+r.item.title.slice(0,60)+'」的想法',type:'想法',project:r.pid,body:'来源：'+r.item.title+'\n'+(r.item.url||'')+'\n\n'+(r.item.note||'')+'\n\n## 研究想法\n\n'});break;
    case 'subscriptions':showModal(forms.subscriptions(context));break;
    case 'remove-subscription':{ui.removedSubscription=data.subscriptions.find(x=>x.id===id);data.subscriptions=data.subscriptions.filter(x=>x.id!==id);touch();showModal(forms.subscriptions(context));notify('订阅已移除',{action:'undo-subscription',id});break;}
    case 'undo-subscription':if(ui.removedSubscription?.id===id){data.subscriptions.push(ui.removedSubscription);ui.removedSubscription=null;touch();showModal(forms.subscriptions(context));}break;
    case 'refresh-feed':await refreshFeed();break;
    case 'new-run':showModal(forms.runForm(context));break;
    case 'edit-run':showModal(forms.runForm(context,id||r.id));break;
    case 'add-metric':$('#metric-rows').insertAdjacentHTML('beforeend',forms.metricRow());$('#metric-rows').closest('form').dataset.dirty='true';$('#metric-rows').lastElementChild.querySelector('input').focus();break;
    case 'remove-metric':el.closest('form').dataset.dirty='true';el.closest('.metric-input-row').remove();break;
    case 'run-view':ui.runView=v;drawPage();if(v==='git'&&r.pr.repo&&!ui.repos[r.pid])await refreshRepo();break;
    case 'run-menu':menu(el,[{label:'编辑实验',action:'edit-run',id,icon:'edit'},{label:'移至回收站',action:'trash-run',id,icon:'trash',danger:true}]);break;
    case 'trash-run':trash('runs',id);break;
    case 'compare':ui.comparisons[r.pid]=runs(r.pid).filter(x=>ui.runSelection.has(x.id)).map(x=>x.id);go('compare/'+r.pid);break;
    case 'run-to-record':showNewRecord({title:r.item.name+' · 实验结论',type:'研究决策',project:r.pid,body:recordText(r.item)});break;
    case 'comparison-record':{const list=runs(r.pid).filter(x=>ui.comparisons[r.pid]?.includes(x.id));const result=metricComparison(list);showNewRecord({title:'实验比较 · '+list.map(x=>x.name).join(' / ').slice(0,100),type:'研究决策',project:r.pid,body:(result.reason?'> '+result.reason+'\n\n':'')+list.map(recordText).join('\n\n')+'\n\n## 比较结论\n\n'});break;}
    case 'run-artifact':{const result=await chooseFiles('any');r.item.artifacts||=[];r.item.artifacts.push(...result.files);touch();drawPage();if(result.errors?.length)notify(result.errors.join(' '));else if(result.files.length)notify('附件已保存');break;}
    case 'download-artifact':await saveAttachment(r.item.artifacts.find(x=>x.id===id));break;
    case 'choose-repo':if(isDesktop){const result=await api('chooseDirectory');if(result.path){const status=await api('repoStatus',result.path);r.pr.repo=result.path;ui.repos[r.pid]={value:status};touch();drawPage();}}else showModal(forms.simpleForm('关联代码仓库','本地仓库的完整路径','repo',r.pr.repo||'','repo',r.pid));break;
    case 'refresh-repo':await refreshRepo();break;
    case 'file-diff':case 'commit-diff':await busyButton(el,async()=>{const result=await api('diff',{repo:r.pr.repo,...(a==='file-diff'?{file:v}:{hash:v})});showModal({title:a==='file-diff'?v:'提交详情',wide:true,body:`<pre class="code-block diff-content">${e(result.text||'没有文本差异。')}</pre>`});});break;
    case 'context':showModal(forms.contextForm(context));break;
    case 'new-session':freshSession(r.pid);persistNavigation();drawConversation();break;
    case 'session':ui.sessionIds[r.pid]=id;ui.chatScrollReset=true;persistNavigation();drawConversation();break;
    case 'session-menu':menu(el,[{label:'重命名',action:'rename-session',id,icon:'edit'},{label:'移至回收站',action:'trash-session',id,icon:'trash',danger:true}]);break;
    case 'rename-session':showModal(forms.simpleForm('重命名对话','对话名称','title',data.sessions.find(x=>x.id===id).title,'rename-session',id));break;
    case 'trash-session':trash('sessions',id);break;
    case 'prompt':await ask(v);break;
    case 'stop-chat':{const pending=ui.requests[id];if(pending){delete ui.requests[id];await api('cancelChat',pending.id);drawConversation();notify('已停止回答');}break;}
    case 'retry-chat':{const s=data.sessions.find(s=>s.id===id);const message=s.messages.findLast(m=>m.role==='user');if(message)await ask(message.text,true);break;}
    case 'copy-answer':await navigator.clipboard.writeText(data.sessions.find(s=>s.id===id).messages[Number(v)].text);notify('已复制');break;
    case 'answer-record':{const s=data.sessions.find(s=>s.id===id);showNewRecord({project:s.project,type:'研究文档',title:s.title,body:s.messages[Number(v)].text});break;}
    case 'check-model':await busyButton(el,async()=>{const form=el.closest('form'),endpoint=form.elements.endpoint.value;const status=$('#model-connection-status');status.textContent='正在检测…';try{const result=await api('models',endpoint);ui.models=result.models;$('#model-select').innerHTML='<option value="">选择模型</option>'+result.models.map(x=>`<option ${x===data.settings.model.model?'selected':''}>${e(x)}</option>`).join('');if(result.models.length===1)$('#model-select').value=result.models[0];status.textContent=result.models.length?'已连接 · '+result.models.length+' 个模型':'已连接，请先在 Ollama 下载模型';form.dataset.dirty='true';}catch(err){status.textContent='连接失败';formError(form,err.message);}});break;
    case 'disconnect-model':data.settings.model.model='';touch();closeModal(true);render();notify('本地助手已断开');break;
    case 'ollama-site':await external('https://ollama.com/download');break;
    case 'reveal-data':await api('revealData');break;
    case 'export-workspace':await flush();if((await saveText('Scientify-'+stamp().slice(0,10)+'.json',JSON.stringify(data,null,2),'application/json')).saved)notify('记录已导出');break;
    case 'import-workspace':await selectWorkspace();break;
    case 'confirm-import':await busyButton(el,async()=>{await flush();const result=await api('importWorkspace',ui.pendingImport);data=validateWorkspace(result.workspace);localStorage.setItem('scientify-workspace-cache-v3',JSON.stringify(data));savedRevision=data.revision;ui.projectId=null;ui.projectSessions={};ui.tabs=['home'];ui.active='home';ui.panel=null;ui.expanded=new Set();ui.repos={};ui.sessionIds={};ui.paperScope='all';closeModal(true);render();notify('记录已导入，原工作区已备份');});break;
    case 'restore-backup':{await api('restoreBackup');localStorage.removeItem('scientify-workspace-cache-v3');location.reload();break;}
    case 'restore':restoreFromTrash(data,id);touch();render();notify('已恢复');break;
    case 'check-tex':await busyButton(el,async()=>{const result=await api('texStatus');$('#tex-environment').textContent=result.available?'已找到 XeLaTeX，可以编译研究文档。':'未找到 XeLaTeX。安装 TeX Live 或 MiKTeX 后重启应用，也可直接导出 .tex 源码。';});break;
    case 'output':if($('#latex-source')&&$('.modal').dataset.dirty==='true'){closeModal();return;}if(!r.pid||!records(r.pid).length){notify('先创建研究记录，再导出内容。');return;}showModal(forms.outputForm(context));break;
    case 'save-source':ui.output.source=$('#latex-source').value;if((await saveText(ui.output.title+'.tex',ui.output.source)).saved){$('.modal').dataset.dirty='false';notify('LaTeX 源码已保存');}break;
    case 'save-markdown':if((await saveText(ui.output.title+'.md','# '+ui.output.title+'\n\n'+ui.output.records.map(x=>'## '+x.title+'\n\n'+x.body).join('\n\n'))).saved)notify('Markdown 已保存');break;
    case 'compile':await busyButton(el,async()=>{ui.output.source=$('#latex-source').value;const feedback=$('#compile-feedback');feedback.innerHTML='<p class="field-help">正在编译…</p>';try{const result=await api('compile',ui.output.source);ui.output.compiled=result.attachment;feedback.innerHTML=`<div class="${result.success?'notice':'inline-error'}">${result.success?'PDF 已生成。':'编译没有完成，请检查源码与日志。'}${result.success?b('保存 PDF','save-compiled',{small:true,icon:'download'}):''}</div><details class="compile-log"><summary>编译日志</summary><pre class="code-block">${e(result.log)}</pre></details>`;}catch(err){feedback.innerHTML=`<div class="inline-error">${e(err.message)}</div>`;}});break;
    case 'save-compiled':await saveAttachment({...ui.output.compiled,name:ui.output.title+'.pdf'});break;
  }
}
async function selectWorkspace(){
  if(Object.keys(ui.requests).length){notify('请先停止正在进行的对话，再导入工作区。');return;}
  const input=document.createElement('input');input.type='file';input.accept='.json';input.hidden=true;document.body.append(input);
  input.oncancel=()=>input.remove();input.onchange=async()=>{try{const file=input.files[0];if(!file)return;if(file.size>15_000_000)throw new Error('工作区文件不能超过 15 MB。');ui.pendingImport=validateWorkspace(JSON.parse(await file.text()));const d=ui.pendingImport;showModal({title:'导入工作区记录',body:`<p>将载入 ${d.projects.length} 个项目、${d.papers.length} 篇文献和 ${d.records.length} 条研究记录。</p><p class="field-help">现有工作区将先保存独立备份，再替换为这些记录。附件需要仍然位于本机数据目录。</p><div class="modal-footer">${b('取消','close-modal')}${b('备份并导入','confirm-import',{primary:true})}</div>`});}catch(err){notify('无法导入：'+err.message);}finally{input.remove();}};input.click();
}
async function onSubmit(form){
  if(!form.reportValidity()||form.dataset.submitting==='true')return;const f=new FormData(form),get=name=>String(f.get(name)||'').trim(),kind=form.dataset.form,id=form.dataset.id,r=info();
  form.dataset.submitting='true';try{await busyButton(form.querySelector('[type="submit"]'),async()=>{
    if(kind==='profile'){if(!get('name'))throw new Error('请填写姓名或昵称。');data.settings.name=get('name');data.settings.profile={institution:get('institution'),field:get('field'),bio:get('bio'),color:get('color')};form.dataset.dirty='false';touch();drawFrame();notify('个人信息已保存');return;}
    if(kind==='team'){if(!get('name'))throw new Error('请填写团队名称。');if(data.teams.some(t=>t.id!==id&&t.name===get('name')))throw new Error('已有同名团队，请换一个名称。');let t=data.teams.find(t=>t.id===id);if(!t){t={id:uid(),createdAt:stamp()};data.teams.push(t);}Object.assign(t,{name:get('name'),institution:get('institution'),description:get('description'),color:get('color'),updatedAt:stamp()});touch();closeModal(true);openSpace(id?'teaminfo/'+t.id:'team/'+t.id);notify(id?'团队信息已保存':'团队空间已创建');return;}
    if(kind==='chat'){await ask(get('question'));return;}
    if(kind==='commit'){await api('commit',{repo:r.pr.repo,files:f.getAll('files'),message:get('message')});notify('代码版本已提交');await refreshRepo();return;}
    if(kind==='subscription'){const keyword=get('keyword'),category=get('category');if(data.subscriptions.some(s=>s.keyword===keyword&&s.category===category))throw new Error('这条订阅已经存在。');data.subscriptions.push({id:uid(),keyword,category,enabled:true});touch();showModal(forms.subscriptions(context));drawPage();notify('已添加订阅');return;}
    if(kind==='model'){if(!get('model'))throw new Error('请先检测连接并选择模型。');const result=await api('models',get('endpoint'));if(!result.models.includes(get('model')))throw new Error('所选模型已不可用，请重新检测连接。');data.settings.model={endpoint:get('endpoint'),model:get('model')};touch();closeModal(true);render();notify('已连接本地模型');return;}
    if(kind==='project'){if(!get('name'))throw new Error('请填写项目名称。');let p=project(id);const created=!p;if(!p){p={id:uid(),createdAt:stamp(),favorite:false,archived:false};data.projects.push(p);}Object.assign(p,{name:get('name'),question:get('question'),stage:get('stage'),field:get('field'),space:get('space')||'personal',color:get('color'),summary:get('summary'),path:get('path'),updatedAt:stamp()});touch((created?'创建了':'更新了')+'「'+p.name+'」');closeModal(true);if(created)enterProject(p.id);else if(isSpaceRoute(r.type))openSpace(p.space==='personal'?'home':'team/'+p.space);else render();if(ui.pendingRecord){const options=ui.pendingRecord;ui.pendingRecord=null;showNewRecord({...options,project:p.id});}return;}
    if(kind==='record'){if(!get('title'))throw new Error('请填写记录标题。');const x={id:uid(),project:get('project'),title:get('title'),type:get('type'),status:get('status'),body:get('initialBody')||(f.has('template')?(templates[get('type')]||'## 问题\n\n\n## 下一步\n'):''),createdAt:stamp(),updatedAt:stamp()};data.records.push(x);touch('创建了「'+x.title+'」');closeModal(true);go('record/'+x.id);$('#record-body')?.focus();return;}
    if(kind==='paper'){if(!get('title'))throw new Error('请填写论文标题。');let x=data.papers.find(x=>x.id===id);if(!x){x={id:uid(),source:'手动添加',library:true,status:'未读',note:'',quotes:[],createdAt:stamp()};data.papers.push(x);}Object.assign(x,{title:get('title'),authors:get('authors'),published:get('published'),tags:get('tags').split(/[,，]/).map(x=>x.trim()).filter(Boolean),url:get('url'),abstract:get('abstract'),projects:f.getAll('projects'),updatedAt:stamp()});touch();closeModal(true);go('paper/'+x.id);return;}
    if(kind==='run'){if(!get('name'))throw new Error('请填写实验名称。');const metrics=parseMetrics([...form.querySelectorAll('.metric-input-row')].map(row=>({name:row.querySelector('[name="metricName"]').value,value:row.querySelector('[name="metricValue"]').value,unit:row.querySelector('[name="metricUnit"]').value,direction:row.querySelector('[name="metricDirection"]').value})));let x=data.runs.find(x=>x.id===id);if(!x){x={id:uid(),project:r.pid,createdAt:stamp(),artifacts:[]};data.runs.push(x);}Object.assign(x,Object.fromEntries(['name','status','protocol','commit','seed','config','environment','command','conclusion'].map(k=>[k,get(k)])),{metrics,updatedAt:stamp()});touch('保存了实验「'+x.name+'」');closeModal(true);go('run/'+x.id);return;}
    if(kind==='task'){if(!get('title'))throw new Error('请填写待办内容。');data.tasks.push({id:uid(),project:id,title:get('title'),done:false,createdAt:stamp()});}
    if(kind==='rename-record'||kind==='rename-session'){if(!get('title'))throw new Error('名称不能为空。');const x=data[kind==='rename-record'?'records':'sessions'].find(x=>x.id===id);x.title=get('title');x.updatedAt=stamp();}
    if(kind==='move-record'){const x=data.records.find(x=>x.id===id);x.project=get('project');x.updatedAt=stamp();}
    if(kind==='repo'){const status=await api('repoStatus',get('repo'));project(id).repo=get('repo');ui.repos[id]={value:status};}
    if(kind==='context'){session(r.pid).context=f.getAll('context');}
    if(kind==='output'){const items=records(r.pid).filter(x=>f.getAll('records').includes(x.id));if(!items.length)throw new Error('至少选择一条研究记录。');ui.output={title:get('title'),records:structuredClone(items),source:exportLatex(get('title'),items)};sourceModal();return;}
    touch();closeModal(true);render();
  });}finally{form.dataset.submitting='false';}
}
function onInput(event){const el=event.target,r=info();if(el.closest('.modal form,form[data-form="profile"]'))el.closest('form').dataset.dirty='true';
  if(el.id==='global-search'){
    clearTimeout(searchTimer);
    const value=el.value;
    searchTimer=setTimeout(()=>{searchTimer=null;if(!searchComposing&&el.isConnected)searchResults(value);},90);
    return;
  }
  if(el.name==='question'){ui.drafts[el.closest('form').dataset.session]=el.value;return;}
  if(el.id==='profile-name'){data.settings.name=el.value;touch();drawFrame();return;}
  if(el.id==='latex-source'){if(ui.output)ui.output.source=el.value;el.closest('.modal').dataset.dirty='true';return;}
  const queries={'project-query':'projectQuery','paper-query':'paperQuery','record-query':'recordQuery','run-query':'runQuery'};
  if(queries[el.id]){ui[queries[el.id]]=el.value;refreshSearchInput(el);return;}
  const props={'record-title':'title','record-body':'body','paper-note':'note','run-conclusion':'conclusion'};
  if(props[el.id]&&r.item){r.item[props[el.id]]=el.id==='record-title'?(el.value.trim()||'无标题'):el.value;r.item.updatedAt=stamp();touch();if(el.id==='record-title')drawFrame();if(el.id==='record-body'){sizeEditor();$('.editor-foot span').textContent=el.value.trim().length+' 字';}}
}
async function onChange(event){const el=event.target,r=info();if(el.closest('.modal form,form[data-form="profile"]'))el.closest('form').dataset.dirty='true';
  if(el.dataset.task){data.tasks.find(x=>x.id===el.dataset.task).done=el.checked;touch();redrawPagePreservingFocus();}
  if(el.dataset.paperCheck){el.checked?ui.paperSelection.add(el.dataset.paperCheck):ui.paperSelection.delete(el.dataset.paperCheck);redrawPagePreservingFocus();}
  if(el.dataset.runCheck){el.checked?ui.runSelection.add(el.dataset.runCheck):ui.runSelection.delete(el.dataset.runCheck);redrawPagePreservingFocus();}
  if(el.dataset.subToggle){data.subscriptions.find(x=>x.id===el.dataset.subToggle).enabled=el.checked;touch();redrawPagePreservingFocus();}
  if(el.id==='project-sort'){ui.projectSort=el.value;drawPage();}
  if(el.id==='paper-scope'){ui.paperScope=el.value;ui.paperSelection.clear();drawPage();}
  if(el.id==='metric-select'){ui.metric=el.value;drawPage();}
  if(el.id==='record-type'||el.id==='record-status'||el.id==='paper-reading-status'){r.item[el.id==='record-type'?'type':'status']=el.value;r.item.updatedAt=stamp();touch();}
  if(el.id==='pdf-page-number'){ui.pdfPage=Math.max(1,Math.min(r.item.pages||9999,Number(el.value)||1));await drawPdf();}
  if(el.id==='pdf-zoom'){ui.pdfZoom=el.value;await drawPdf();}
  if(el.id==='theme-select'){data.settings.theme=el.value;touch();applyTheme();}
  if(el.id==='record-title'&&!el.value.trim()){r.item.title='无标题';el.value=r.item.title;touch();drawFrame();}
}
function onKey(event){if(event.isComposing)return;const key=event.key.toLowerCase(),modifier=event.ctrlKey||event.metaKey,modal=$('.modal');
  if(event.key==='Escape'){if($('.context-menu')){closeMenu();ui.menuFocus?.focus();}else if(modal){if(ui.suspended)restoreEditor();else closeModal();}else if(ui.panel){ui.panel=null;drawInspector();drawFrame();persistNavigation();}return;}
  if(modal&&event.key==='Tab'){const focusable=[...modal.querySelectorAll('button:not(:disabled),input:not([type="hidden"]):not(:disabled),textarea:not(:disabled),select:not(:disabled),summary,[tabindex="0"]')].filter(x=>x.getClientRects().length);const first=focusable[0],last=focusable.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}
  if($('.context-menu')&&['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();const buttons=[...$('.context-menu').querySelectorAll('button')],index=buttons.indexOf(document.activeElement);buttons[(index+(event.key==='ArrowDown'?1:buttons.length-1))%buttons.length]?.focus();return;}
  if(event.target.name==='question'&&event.key==='Enter'&&!event.shiftKey){event.preventDefault();event.target.closest('form').requestSubmit();return;}
  if(modal&&elSearchKey(event))return;
  // Tabs use a roving tab stop. Arrow keys activate the adjacent page, while
  // Ctrl/Cmd+Tab mirrors the familiar editor tab switcher.
  const tabButton=event.target.closest?.('#tabs .tab-main[role="tab"]');
  const tabButtons=[...document.querySelectorAll('#tabs .tab-main[role="tab"]')];
  if(!modal&&tabButtons.length&&(tabButton||(modifier&&event.key==='Tab'))){
    if(modifier&&event.key==='Tab'){
      event.preventDefault();
      const current=Math.max(0,tabButtons.findIndex(el=>el.dataset.key===ui.active));
      const delta=event.shiftKey?-1:1;
      const next=tabButtons[(current+delta+tabButtons.length)%tabButtons.length];
      next&&focusTab(next.dataset.key,true);
      return;
    }
    if(tabButton&&['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){
      event.preventDefault();
      const current=Math.max(0,tabButtons.indexOf(tabButton));
      const nextIndex=event.key==='Home'?0:event.key==='End'?tabButtons.length-1:(current+(event.key==='ArrowLeft'?-1:1)+tabButtons.length)%tabButtons.length;
      focusTab(tabButtons[nextIndex].dataset.key,true);
      return;
    }
  }
  // A board card remains keyboard reachable even though its visual affordance
  // is a draggable card. Left/right moves it through the same ordered states.
  const card=event.target.closest?.('[data-drag-record]');
  if(!modal&&!$('.context-menu')&&card&&['ArrowLeft','ArrowRight','Enter',' '].includes(event.key)){
    const record=data.records.find(x=>x.id===card.dataset.dragRecord);
    if(record){
      if(event.key==='Enter'||event.key===' '){
        if(event.target===card){event.preventDefault();go('record/'+record.id);}
      }else{
        const index=recordStates.indexOf(record.status),nextIndex=index+(event.key==='ArrowRight'?1:-1);
        if(nextIndex>=0&&nextIndex<recordStates.length){event.preventDefault();moveRecordStatus(record.id,recordStates[nextIndex]);}
      }
      return;
    }
  }
  if(!modifier)return;
  if(key==='s'){event.preventDefault();if($('form[data-form="profile"]')){$('form[data-form="profile"]').requestSubmit();return;}if(modal?.querySelector('form'))modal.querySelector('form').requestSubmit();else void flush().then(()=>notify('已保存')).catch(err=>notify(err.message));return;}
  if(modal)return;
  if(key==='k'){event.preventDefault();if(guardProfile())return;if(isSpaceRoute(info().type)){if(!$('#project-query'))openSpace('home');$('#project-query')?.focus();}else searchModal();}
  if(key==='j'&&info().pid){event.preventDefault();ui.panel=ui.panel==='ai'?null:'ai';persistNavigation();drawFrame();drawInspector();}
  if(key==='n'){event.preventDefault();if(guardProfile())return;if(isSpaceRoute(info().type))showModal(forms.projectForm(context));else showNewRecord();}
  if(key==='w'){event.preventDefault();closeTab(ui.active);}
}

function elSearchKey(event){if(!$('#global-search'))return false;const results=[...document.querySelectorAll('#search-results button')];if(event.key==='Enter'&&event.target.id==='global-search'){event.preventDefault();results[0]?.click();return true;}if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();const index=results.indexOf(document.activeElement);results[(index+(event.key==='ArrowDown'?1:results.length-1)+results.length)%results.length]?.focus();return true;}return false;}

async function boot(){renderTitle();$('#page').innerHTML='<div class="loading-content"><span class="spinner"></span>正在打开工作区…</div>';
  try{let legacy;try{legacy=localStorage.getItem('scientify-desktop-v2');savedMirror=JSON.parse(localStorage.getItem('scientify-workspace-cache-v3'));}catch{}if(legacy)await api('preserveLegacy',legacy);
    const result=await request('load');if(result.error){$('#page').innerHTML=empty('folder','暂时无法打开工作区',result.error,b('恢复最近备份','restore-backup',{primary:true})+(isDesktop?b('打开数据目录','reveal-data'):''));return;}
    data=result.workspace?validateWorkspace(result.workspace):savedMirror?validateWorkspace(savedMirror):emptyWorkspace();
    if(result.workspace&&savedMirror?.schema===3&&savedMirror.revision>data.revision&&savedMirror.updatedAt>data.updatedAt)data=validateWorkspace(savedMirror);
    savedRevision=result.workspace?.revision??-1;ui.tabs=(data.navigation.tabs||['home']).filter(key=>info(key).valid);if(!ui.tabs.includes('home'))ui.tabs.unshift('home');ui.active=ui.tabs.includes(data.navigation.active)?data.navigation.active:'home';ui.expanded=new Set(data.navigation.expanded||[]);ui.panel=data.navigation.panel;ui.comparisons=data.navigation.comparisons||{};
    ui.projectSessions=data.navigation.projectSessions||{};ui.sessionIds={...(data.navigation.sessionIds||{})};ui.projectId=null;ui.tabs=['home'];ui.active='home';ui.panel=null;
    if(info().type==='paper')ui.pdfPage=info().item.lastPage||1;
    ready=true;render();if(data.revision!==savedRevision)await flush();
  }catch(err){$('#page').innerHTML=empty('folder','工作区暂时无法打开',err.message,b('重新打开','reload',{primary:true}));}
}

document.addEventListener('click',event=>void onClick(event).catch(err=>notify(err.message)));
document.addEventListener('submit',event=>{if(event.target.dataset.form){event.preventDefault();void onSubmit(event.target).catch(err=>formError(event.target,err.message));}});
document.addEventListener('input',onInput);document.addEventListener('change',event=>void onChange(event).catch(err=>notify(err.message)));document.addEventListener('keydown',onKey);
document.addEventListener('compositionstart',event=>{if(isSearchInput(event.target))searchComposing=true;});
document.addEventListener('compositionend',event=>{if(!isSearchInput(event.target))return;searchComposing=false;if(event.target.id==='global-search')searchResults(event.target.value);else refreshSearchInput(event.target);});
document.addEventListener('dragstart',event=>{const card=event.target.closest('[data-drag-record]');if(!card||event.target.closest('[data-action="record-menu"]'))return;card.setAttribute('aria-grabbed','true');card.classList.add('dragging');event.dataTransfer.setData('text/scientify-record',card.dataset.dragRecord);event.dataTransfer.effectAllowed='move';});
document.addEventListener('dragover',event=>{const lane=event.target.closest('[data-drop-status]');if(lane&&event.dataTransfer.types.includes('text/scientify-record')){event.preventDefault();document.querySelectorAll('[data-drop-status].drag-over').forEach(el=>{if(el!==lane)el.classList.remove('drag-over');});lane.classList.add('drag-over');}});
document.addEventListener('dragleave',event=>{const lane=event.target.closest('[data-drop-status]');if(lane&&!lane.contains(event.relatedTarget))lane.classList.remove('drag-over');});
document.addEventListener('dragend',event=>{event.target.closest('[data-drag-record]')?.classList.remove('dragging');event.target.closest('[data-drag-record]')?.setAttribute('aria-grabbed','false');document.querySelectorAll('[data-drop-status].drag-over').forEach(el=>el.classList.remove('drag-over'));});
document.addEventListener('drop',event=>{const lane=event.target.closest('[data-drop-status]');if(!lane)return;const id=event.dataTransfer.getData('text/scientify-record'),record=data.records.find(x=>x.id===id&&x.project===info().pid);if(!record)return;event.preventDefault();moveRecordStatus(id,lane.dataset.dropStatus);document.querySelectorAll('[data-drop-status].drag-over').forEach(el=>el.classList.remove('drag-over'));});
document.addEventListener('mouseup',()=>{const selection=window.getSelection();if(info().type==='paper'&&selection?.toString().trim()&&$('#pdf-host')?.contains(selection.anchorNode)){ui.selection=selection.toString().trim();$('#pdf-selection-bar')?.classList.remove('hidden');}});
document.addEventListener('dblclick',event=>{if(isDesktop&&event.target.closest('#titlebar')&&!event.target.closest('button'))void api('windowAction','maximize');});
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',applyTheme);
if(isDesktop)window.scientify.onFlush(async()=>{try{if($('form[data-form="profile"]')?.dataset.dirty==='true'){await api('cancelClose');guardProfile();return;}if($('.modal [data-dirty="true"]')||$('.modal')?.dataset.dirty==='true'||ui.suspended){await api('cancelClose');if(!ui.suspended)closeModal();return;}await flush();await api('closeReady');}catch{notify('尚未保存成功，请重试后关闭。');}});
window.addEventListener('beforeunload',event=>{if(!isDesktop&&ready&&(ui.saveState!=='saved'||$('form[data-form="profile"]')?.dataset.dirty==='true')){event.preventDefault();event.returnValue='';}});
void boot();
