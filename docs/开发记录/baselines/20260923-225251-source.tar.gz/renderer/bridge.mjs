export const isDesktop = Boolean(window.scientify?.desktop);
export async function request(method, value) {
  let result;
  if (isDesktop) result = await window.scientify.request(method, value);
  else {
    const response = await fetch('/api/' + method, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ value }) });
    result = await response.json();
  }
  return result;
}
export async function api(method, value) {
  const result = await request(method, value);
  if (result?.error) throw new Error(result.error);
  return result;
}
export function base64Bytes(base64) { const binary = atob(base64); return Uint8Array.from(binary, x => x.charCodeAt(0)); }
export async function chooseFiles(kind = 'pdf') {
  if (isDesktop) return api('importFiles', kind);
  return new Promise(resolve => {
    const input = document.createElement('input'); input.type = 'file'; input.multiple = kind !== 'pdf-single'; input.hidden = true; input.accept = kind.startsWith('pdf') ? '.pdf' : '';
    input.oncancel = () => { input.remove(); resolve({ files: [] }); };
    input.onchange = async () => {
      const files = [], errors = [];
      for (const file of input.files) {
        if (file.size > 50 * 1024 * 1024) { errors.push(file.name + ' 超过 50 MB'); continue; }
        try {
          const base64 = await new Promise((yes, no) => { const reader = new FileReader(); reader.onload = () => yes(reader.result.split(',')[1]); reader.onerror = no; reader.readAsDataURL(file); });
          files.push(await api('importBuffer', { name: file.name, base64 }));
        } catch (err) { errors.push(file.name + '：' + err.message); }
      }
      input.remove(); resolve({ files, errors });
    };
    document.body.append(input); input.click();
  });
}
export async function saveText(name, content, type = 'text/plain;charset=utf-8') {
  if (isDesktop) return api('saveText', { name, content });
  download(name, new Blob([content], { type })); return { saved: true };
}
export function download(name, blob) { const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 10000); }
export async function saveAttachment(attachment) {
  if (isDesktop) return api('saveAttachment', attachment);
  const value = await api('readAttachment', attachment.id); download(attachment.name, new Blob([base64Bytes(value.base64)])); return { saved: true };
}
export function external(url) { if (isDesktop) return api('openExternal', url); const link = new URL(url); if (['https:', 'http:'].includes(link.protocol)) window.open(url, '_blank', 'noopener,noreferrer'); }
