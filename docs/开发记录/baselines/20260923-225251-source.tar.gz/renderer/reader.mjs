import * as pdf from './vendor/pdf.mjs';
import { api, base64Bytes } from './bridge.mjs';
pdf.GlobalWorkerOptions.workerSrc = new URL('./vendor/pdf.worker.mjs', import.meta.url).href;
const documents = new Map();
let activeRender, renderVersion = 0;
export async function documentFor(id) {
  if (!documents.has(id)) {
    const result = await api('readAttachment', id);
    const promise = pdf.getDocument({ data: base64Bytes(result.base64), cMapUrl: new URL('./vendor/cmaps/', import.meta.url).href, cMapPacked: true, standardFontDataUrl: new URL('./vendor/standard_fonts/', import.meta.url).href, wasmUrl: new URL('./vendor/wasm/', import.meta.url).href }).promise;
    documents.set(id, promise);
    promise.catch(() => documents.delete(id));
    if (documents.size > 4) { const first = documents.keys().next().value; const old = documents.get(first); documents.delete(first); old.then(doc => doc.destroy()).catch(() => {}); }
  }
  return documents.get(id);
}
export async function pdfMetadata(id) {
  const doc = await documentFor(id); const { info } = await doc.getMetadata().catch(() => ({ info: {} }));
  return { pages: doc.numPages, title: info?.Title && info.Title !== 'untitled' ? info.Title.trim() : '', authors: info?.Author?.trim() || '' };
}
export function cancelPdfRender() { renderVersion++; activeRender?.cancel(); activeRender = null; }
export async function renderPdf(id, pageNumber, zoom, host, onReady) {
  cancelPdfRender(); const version = renderVersion;
  const doc = await documentFor(id); if (version !== renderVersion || !host.isConnected) return;
  const number = Math.max(1, Math.min(doc.numPages, pageNumber || 1)); const page = await doc.getPage(number);
  const base = page.getViewport({ scale: 1 }); const scale = zoom === 'fit' ? Math.max(.35, (host.clientWidth - 48) / base.width) : Number(zoom);
  const viewport = page.getViewport({ scale }); const dpr = Math.min(devicePixelRatio || 1, 2);
  const wrap = document.createElement('div'); wrap.className = 'pdf-canvas-page'; wrap.style.width = viewport.width + 'px'; wrap.style.height = viewport.height + 'px';
  wrap.style.setProperty('--scale-factor', scale); wrap.style.setProperty('--total-scale-factor', scale); wrap.style.setProperty('--user-unit', 1);
  const canvas = document.createElement('canvas'); canvas.setAttribute('aria-label', `PDF 第 ${number} 页`); canvas.width = Math.floor(viewport.width * dpr); canvas.height = Math.floor(viewport.height * dpr); canvas.style.width = viewport.width + 'px'; canvas.style.height = viewport.height + 'px';
  const layer = document.createElement('div'); layer.className = 'textLayer'; wrap.append(canvas, layer); host.replaceChildren(wrap);
  activeRender = page.render({ canvasContext: canvas.getContext('2d'), viewport, transform: dpr === 1 ? undefined : [dpr, 0, 0, dpr, 0, 0] });
  try { await activeRender.promise; } catch (err) { if (err.name === 'RenderingCancelledException') return; throw err; }
  if (version !== renderVersion) return;
  const text = await page.getTextContent();
  await new pdf.TextLayer({ textContentSource: text, container: layer, viewport }).render();
  onReady({ page: number, pages: doc.numPages, text: text.items.map(x => x.str).filter(Boolean).join(' ') });
}
export async function extractPdfText(id, limit = 50000) {
  const doc = await documentFor(id); let text = '';
  for (let i = 1; i <= Math.min(doc.numPages, 30) && text.length < limit; i++) {
    const page = await doc.getPage(i), content = await page.getTextContent(); text += `\n[第 ${i} 页]\n` + content.items.map(x => x.str).filter(Boolean).join(' ');
  }
  return text.slice(0, limit);
}
