export const uid = () => crypto.randomUUID();
export const stamp = () => new Date().toISOString();
export const recordTypes = ['想法', '研究问题', '假设', '实验设计', '研究决策', '组会记录', '研究文档'];
export const recordStates = ['待梳理', '待验证', '进行中', '已完成'];
export const templates = {
  '想法': '## 想要解决的问题\n\n\n## 初步思路\n\n\n## 下一步\n',
  '实验设计': '## 研究假设\n\n\n## 基线与对照\n\n\n## 自变量与控制条件\n\n\n## 数据划分\n\n\n## 评价指标与失败判据\n\n\n## 执行步骤\n',
  '研究决策': '## 决策\n\n\n## 考虑过的方案\n\n\n## 选择的理由\n\n\n## 后续行动\n',
  '组会记录': '## 本周进展\n\n\n## 需要讨论的问题\n\n\n## 讨论结论\n\n\n## 下一步\n',
  '研究文档': '## 研究问题\n\n\n## 方法与思路\n\n\n## 当前进展\n\n\n## 下一步\n'
};
export function emptyWorkspace() {
  return { schema: 3, revision: 0, updatedAt: stamp(), teams: [], projects: [], papers: [], records: [], runs: [], tasks: [], sessions: [], subscriptions: [], trash: [], recent: [], activity: [], settings: { theme: 'system', name: '', model: { endpoint: 'http://127.0.0.1:11434', model: '' } }, navigation: { tabs: ['home'], active: 'home', expanded: [], panel: null } };
}
const collections = ['projects', 'papers', 'records', 'runs', 'tasks', 'sessions', 'subscriptions'];
export function validateWorkspace(input) {
  if (!input || input.schema !== 3) throw new Error('这不是受支持的 Scientify 工作区文件。');
  for (const key of collections) {
    if (!Array.isArray(input[key]) || input[key].length > 50000) throw new Error(`工作区中的 ${key} 数据不完整。`);
    const ids = new Set();
    for (const item of input[key]) {
      if (!item || typeof item.id !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(item.id) || ids.has(item.id)) throw new Error('工作区包含无效或重复的记录标识。');
      ids.add(item.id);
    }
  }
  const projectIds = new Set(input.projects.map(p => p.id));
  for (const key of ['records', 'runs', 'tasks', 'sessions']) for (const item of input[key]) {
    if (!projectIds.has(item.project)) throw new Error('部分记录的所属项目不存在，无法导入。');
  }
  for (const p of input.papers) if (!Array.isArray(p.projects) || p.projects.some(id => !projectIds.has(id))) throw new Error('文献的项目归属不完整。');
  for (const r of input.runs) {
    if (!Array.isArray(r.metrics)) throw new Error('实验指标格式不正确。');
    for (const m of r.metrics) if (typeof m.name !== 'string' || !m.name.trim() || (m.value !== null && (typeof m.value !== 'number' || !Number.isFinite(m.value)))) throw new Error('实验指标包含无效数值。');
  }
  const teamIds = new Set();
  for(const t of input.teams||[]){if(!t||typeof t.id!=='string'||!t.id.match(/^[a-zA-Z0-9_-]{1,80}$/)||t.id==='personal'||teamIds.has(t.id)||typeof t.name!=='string'||!t.name.trim())throw new Error('团队信息无效。');teamIds.add(t.id);}
  for(const p of input.projects)if(p.space&&p.space!=='personal'&&!teamIds.has(p.space))throw new Error('项目所属团队不存在。');
  const base = emptyWorkspace();
  const result = { ...base, ...structuredClone(input) };
  result.teams ||= [];
  for(const p of result.projects)p.space ||= 'personal';
  for(const t of result.teams){if(!/^#[a-fA-F0-9]{6}$/.test(t.color||''))t.color='#657b71';}
  result.settings = { ...base.settings, ...result.settings, model: { ...base.settings.model, ...result.settings?.model } };
  result.trash = Array.isArray(result.trash) ? result.trash : [];
  result.recent = Array.isArray(result.recent) ? result.recent : [];
  result.activity = Array.isArray(result.activity) ? result.activity : [];
  result.navigation = { ...base.navigation, ...result.navigation };
  if (!Number.isSafeInteger(result.revision) || result.revision < 0) throw new Error('工作区版本信息无效。');
  const strings = (items, fields) => { for (const item of items) for (const name of fields) if (typeof item[name] !== 'string') throw new Error('工作区包含无效的文本字段：' + name); };
  strings(result.projects,['name','question','createdAt']);
  strings(result.records,['title','body','type','status','createdAt','updatedAt']);
  strings(result.papers,['title','authors','note','status']);
  strings(result.runs,['name','protocol','conclusion','config','status','updatedAt']);
  strings(result.tasks,['title']); strings(result.sessions,['title','updatedAt']); strings(result.subscriptions,['keyword','category']);
  for (const p of result.papers) if (!Array.isArray(p.tags)||!Array.isArray(p.quotes)) throw new Error('文献笔记格式不正确。');
  for (const s of result.sessions) { if (!Array.isArray(s.messages)||!Array.isArray(s.context)) throw new Error('对话格式不正确。'); for(const m of s.messages) if(!['user','assistant'].includes(m.role)||typeof m.text!=='string')throw new Error('对话内容无效。'); }
  for (const t of result.trash) if (!t||!['records','papers','runs','sessions'].includes(t.collection)||!t.value?.id) throw new Error('回收站数据无效。');
  if(!Array.isArray(result.navigation.tabs)||!Array.isArray(result.navigation.expanded)) throw new Error('工作区导航格式无效。');
  if(result.navigation.tabs.some(x=>typeof x!=='string')||result.recent.some(x=>typeof x?.key!=='string')) throw new Error('工作区标签格式无效。');
  if(typeof result.settings.name!=='string'||typeof result.settings.model.endpoint!=='string'||typeof result.settings.model.model!=='string') throw new Error('工作区设置格式无效。');
  for(const p of result.projects)if(p.color&&!/^#[a-fA-F0-9]{6}$/.test(p.color))p.color='#738c80';
  for(const p of result.papers){if(p.tags.some(x=>typeof x!=='string')||p.quotes.some(q=>typeof q?.text!=='string'||!Number.isInteger(q.page)||!q.id))throw new Error('文献摘录格式无效。');}
  return result;
}
export function moveToTrash(workspace, collection, id) {
  if (!['records', 'papers', 'runs', 'sessions'].includes(collection)) throw new Error('不支持移除该内容。');
  const index = workspace[collection].findIndex(x => x.id === id);
  if (index < 0) return null;
  const [value] = workspace[collection].splice(index, 1);
  const item = { id: uid(), collection, value, deletedAt: stamp() };
  workspace.trash.unshift(item);
  return item;
}
export function restoreFromTrash(workspace, trashId) {
  const index = workspace.trash.findIndex(x => x.id === trashId);
  if (index < 0) return null;
  const entry = workspace.trash[index];
  if (workspace[entry.collection].some(x => x.id === entry.value.id)) throw new Error('同名标识的内容已存在，无法恢复。');
  if (entry.value.project && !workspace.projects.some(p => p.id === entry.value.project)) throw new Error('请先恢复所属项目。');
  const candidate = structuredClone(workspace);
  candidate[entry.collection].push(structuredClone(entry.value));
  validateWorkspace(candidate);
  workspace[entry.collection].push(entry.value);
  workspace.trash.splice(index, 1);
  return entry;
}
export function metricComparison(runs) {
  const keys = new Map();
  for (const run of runs) for (const m of run.metrics) {
    const key = JSON.stringify([m.name, m.unit || '', m.direction || 'max']);
    if (!keys.has(key)) keys.set(key, { name: m.name, unit: m.unit || '', direction: m.direction || 'max', key });
  }
  const protocols = new Set(runs.map(r => (r.protocol || '').trim()).filter(Boolean));
  const comparable = protocols.size === 1 && runs.every(r => (r.protocol || '').trim());
  const rows = [...keys.values()].map(metric => {
    const values = runs.map(r => r.metrics.find(m => JSON.stringify([m.name, m.unit || '', m.direction || 'max']) === metric.key)?.value ?? null);
    const numbers = values.filter(v => typeof v === 'number' && Number.isFinite(v));
    const best = comparable && numbers.length >= 2 ? (metric.direction === 'min' ? Math.min(...numbers) : Math.max(...numbers)) : null;
    return { ...metric, values, best };
  });
  return { rows, comparable, reason: comparable ? '' : protocols.size > 1 ? '这些实验使用了不同的评价设置，请先确认结果是否可直接比较。' : '填写相同的评价设置后，可以标记每项指标的最佳结果。' };
}
export function parseMetrics(rows) {
  const used = new Set();
  return rows.filter(r => r.name.trim() || String(r.value).trim()).map(r => {
    const name = r.name.trim();
    if (!name) throw new Error('请为每项指标填写名称。');
    if (used.has(name)) throw new Error(`指标「${name}」重复。`);
    used.add(name);
    const value = String(r.value).trim() === '' ? null : Number(r.value);
    if (value !== null && !Number.isFinite(value)) throw new Error(`指标「${name}」需要填写有效数字。`);
    return { name, value, unit: r.unit.trim(), direction: r.direction === 'min' ? 'min' : 'max' };
  });
}
export function latexEscape(value) {
  return String(value).replace(/[\\{}$&#%_^~]/g, c => ({ '\\':'\\textbackslash{}', '{':'\\{', '}':'\\}', '$':'\\$', '&':'\\&', '#':'\\#', '%':'\\%', '_':'\\_', '^':'\\textasciicircum{}', '~':'\\textasciitilde{}' }[c]));
}
export function exportLatex(title, records) {
  const content = records.map(r => '\\section{' + latexEscape(r.title) + '}\n' + r.body.split('\n').map(line => {
    const heading = line.match(/^#{1,6}\s+(.+)/);
    return heading ? '\\subsection{' + latexEscape(heading[1]) + '}' : latexEscape(line);
  }).join('\n\n')).join('\n\n');
  return '\\documentclass[UTF8,a4paper,11pt]{ctexart}\n\\usepackage[margin=2.5cm]{geometry}\n\\usepackage{amsmath}\n\\title{' + latexEscape(title) + '}\n\\author{}\n\\date{\\today}\n\\begin{document}\n\\maketitle\n' + content + '\n\\end{document}\n';
}
