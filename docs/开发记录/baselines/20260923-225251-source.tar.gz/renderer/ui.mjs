import { icon } from './icons.mjs';
export const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
export const tag = (text, color = '') => `<span class="pill ${color}">${escape(text)}</span>`;
export function button(text, action, opts = {}) { return `<button type="button" class="btn ${opts.primary?'primary':''} ${opts.flat?'flat':''} ${opts.small?'small':''}" data-action="${action}" ${opts.id?`data-id="${escape(opts.id)}"`:''} ${opts.key?`data-key="${escape(opts.key)}"`:''} ${opts.value?`data-value="${escape(opts.value)}"`:''} ${opts.disabled?'disabled':''}>${opts.icon?icon(opts.icon):''}${text}</button>`; }
export function empty(iconName, title, body, actions = '') { return `<div class="empty-state"><span class="empty-icon">${icon(iconName)}</span><h2>${escape(title)}</h2><p>${escape(body)}</p>${actions?`<div class="actions">${actions}</div>`:''}</div>`; }
export function date(value, full = false) { if (!value) return ''; const d = new Date(value); if (isNaN(d)) return String(value); return new Intl.DateTimeFormat('zh-CN', full?{year:'numeric',month:'short',day:'numeric'}:{month:'short',day:'numeric'}).format(d); }
export function relative(value) { if (!value) return ''; const diff = Date.now()-new Date(value).getTime(); return diff<60000?'刚刚':diff<3600000?Math.floor(diff/60000)+' 分钟前':diff<86400000?Math.floor(diff/3600000)+' 小时前':date(value); }
export function markdown(source) {
  const inline = s => escape(s).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*]+)\*/g,'<em>$1</em>');
  let output = '', list = false, code = false, block = '';
  for (const line of String(source || '').split('\n')) {
    if (line.startsWith('```')) { if (list) {output+='</ul>';list=false;} if(code){output+='<pre><code>'+escape(block)+'</code></pre>';block='';} code=!code; continue; }
    if(code){block+=line+'\n';continue;}
    const bullet=line.match(/^\s*[-*]\s+(.+)/); if(bullet){if(!list){output+='<ul>';list=true;}output+='<li>'+inline(bullet[1])+'</li>';continue;}
    if(list){output+='</ul>';list=false;}
    const heading=line.match(/^(#{1,4})\s+(.+)/); if(heading)output+=`<h${heading[1].length+1}>${inline(heading[2])}</h${heading[1].length+1}>`;else if(line.startsWith('> '))output+='<blockquote>'+inline(line.slice(2))+'</blockquote>';else if(line.trim())output+='<p>'+inline(line)+'</p>';else output+='<div class="paragraph-space"></div>';
  }
  if(list)output+='</ul>';if(code)output+='<pre><code>'+escape(block)+'</code></pre>';return output;
}
