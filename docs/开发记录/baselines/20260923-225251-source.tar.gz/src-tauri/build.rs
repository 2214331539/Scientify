fn main() {
    tauri_build::try_build(tauri_build::Attributes::new().app_manifest(
        tauri_build::AppManifest::new().commands(&[
            "workspace_load",
            "workspace_save",
            "workspace_restore",
            "workspace_migrate_legacy",
            "workspace_import",
            "workspace_export",
            "choose_directory",
        ]),
    ))
    .expect("failed to build Tauri manifest");
}
