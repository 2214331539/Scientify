const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');
const { Services, friendly } = require('./electron/services.cjs');
const root = path.join(__dirname, 'renderer');
const service = new Services(path.join(__dirname, '.preview-data'));
const port = Number(process.env.SCIENTIFY_PREVIEW_PORT || 8791);
const allowed = new Set(['load','save','restoreBackup','preserveLegacy','importWorkspace','readAttachment','models','chat','cancelChat','papers','downloadPaper','repoStatus','diff','commit','texStatus','compile']);
http.createServer(async (req,res) => {
  try {
    if (!['127.0.0.1:'+port,'localhost:'+port].includes(req.headers.host)) { res.writeHead(403);res.end();return; }
    const url = new URL(req.url,'http://127.0.0.1:'+port);
    if (url.pathname.startsWith('/api/')) {
      res.setHeader('Content-Type','application/json; charset=utf-8');
      if(req.method!=='POST'||(req.headers.origin&&!['http://127.0.0.1:'+port,'http://localhost:'+port].includes(req.headers.origin))||req.headers['sec-fetch-site']==='cross-site') {res.writeHead(403);res.end('{}');return;}
      const method=url.pathname.slice(5);
      if(!allowed.has(method)&&method!=='importBuffer')throw new Error('此操作需要在 Scientify 桌面应用中完成。');
      let size=0;const chunks=[];
      for await(const chunk of req){size+=chunk.length;if(size>72*1024*1024)throw new Error('文件过大。');chunks.push(chunk);}
      const {value}=JSON.parse(Buffer.concat(chunks).toString());
      const result=method==='importBuffer'?await service.importBuffer(value.name,value.base64):await service[method](value);
      res.end(JSON.stringify(result));return;
    }
    const relative=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
    const filename=path.resolve(root,'.'+relative);
    if(!filename.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
    const bytes=await fs.readFile(filename);
    const mime={'.html':'text/html','.css':'text/css','.js':'text/javascript','.mjs':'text/javascript','.wasm':'application/wasm','.svg':'image/svg+xml','.ttf':'font/ttf','.woff2':'font/woff2'}[path.extname(filename)]||'application/octet-stream';
    res.setHeader('Content-Type',mime);res.setHeader('Cache-Control','no-store');res.end(bytes);
  }catch(err){if(!res.headersSent){res.statusCode=req.url.startsWith('/api/')?200:404;res.setHeader('Content-Type','application/json; charset=utf-8');}res.end(JSON.stringify({error:friendly(err)}));}
}).listen(port,'127.0.0.1',()=>console.log('Scientify renderer: http://127.0.0.1:'+port));
