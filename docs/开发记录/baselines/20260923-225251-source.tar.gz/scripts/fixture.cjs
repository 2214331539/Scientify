// Small authored document for manual PDF-reader verification; never seed user data.
const fs=require('node:fs'),path=require('node:path');
const strings=['Scientify PDF reader verification','Page two: independent rendering and notes.'];
const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R 5 0 R] /Count 2 >>'];
for(let n=0;n<2;n++){const text=`BT /F1 20 Tf 60 730 Td (${strings[n]}) Tj 0 -40 Td /F1 12 Tf (Select this sentence to save a quotation.) Tj ET`;objects.push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 7 0 R >> >> /Contents ${4+n*2} 0 R >>`,`<< /Length ${Buffer.byteLength(text)} >>\nstream\n${text}\nendstream`);}
objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
let pdf='%PDF-1.4\n',offsets=[0];objects.forEach((o,i)=>{offsets.push(Buffer.byteLength(pdf));pdf+=`${i+1} 0 obj\n${o}\nendobj\n`;});const xref=Buffer.byteLength(pdf);pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`+offsets.slice(1).map(o=>String(o).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
fs.mkdirSync('.test-artifacts',{recursive:true});fs.writeFileSync(path.join('.test-artifacts','reader-check.pdf'),pdf);console.log('Created .test-artifacts/reader-check.pdf');
