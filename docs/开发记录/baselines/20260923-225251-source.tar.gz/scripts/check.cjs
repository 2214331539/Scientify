const fs=require('node:fs');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
for(const dir of ['electron','renderer','scripts']) for(const name of fs.readdirSync(dir)) {
  if(!/\.(?:mjs|cjs|js)$/.test(name))continue;
  const result=spawnSync(process.execPath,['--check',path.join(dir,name)],{stdio:'inherit'});
  if(result.status)process.exit(result.status);
}
console.log('Source syntax checks passed.');
