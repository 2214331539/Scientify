const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('scientify', {
  desktop: true,
  request: (method, value) => ipcRenderer.invoke('scientify:request', { method, value }),
  onFlush: callback => ipcRenderer.on('scientify:flush', () => callback())
});
