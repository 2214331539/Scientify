const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const { Services, friendly } = require('./services.cjs');
app.setPath('userData', path.join(app.getPath('appData'), 'scientify-desktop-sample'));
app.setName('Scientify');
let mainWindow, service, closing = false, closeTimer;
const handlers = {
  load: () => service.load(), save: value => service.save(value), restoreBackup: () => service.restoreBackup(), importWorkspace: value => service.importWorkspace(value),
  preserveLegacy: value => service.preserveLegacy(value), readAttachment: id => service.readAttachment(id),
  importBuffer: value => service.importBuffer(value.name, value.base64), models: value => service.models(value),
  chat: value => service.chat(value), cancelChat: id => service.cancelChat(id), papers: value => service.papers(value),
  downloadPaper: id => service.downloadPaper(id), repoStatus: repo => service.repoStatus(repo),
  diff: value => service.diff(value), commit: value => service.commit(value), texStatus: () => service.texStatus(), compile: value => service.compile(value),
  importFiles: async kind => {
    const result = await dialog.showOpenDialog(mainWindow, { title: kind.startsWith('pdf') ? '导入论文 PDF' : '添加文件', properties: kind === 'pdf-single' ? ['openFile'] : ['openFile', 'multiSelections'], filters: kind.startsWith('pdf') ? [{ name: 'PDF', extensions: ['pdf'] }] : undefined });
    if (result.canceled) return { files: [] };
    const files = [], errors = [];
    for (const filename of result.filePaths) { try { files.push(await service.importPath(filename)); } catch (err) { errors.push(path.basename(filename) + '：' + friendly(err)); } }
    return { files, errors };
  },
  chooseDirectory: async () => { const r = await dialog.showOpenDialog(mainWindow, { title: '选择项目目录', properties: ['openDirectory', 'createDirectory'] }); return { path: r.canceled ? null : r.filePaths[0] }; },
  openDirectory: async directory => {
    const loaded = await service.load();
    if (!loaded.workspace?.projects.some(p => p.path === directory || p.repo === directory)) throw new Error('请先将目录关联到项目。');
    const error = await shell.openPath(directory); if (error) throw new Error('无法打开目录，请确认它仍然存在。'); return {};
  },
  revealData: async () => { await service.init(); await shell.openPath(service.directory); return {}; },
  revealAttachment: id => { shell.showItemInFolder(service.attachmentPath(id)); return {}; },
  openExternal: async value => { const url = new URL(value); if (!['https:', 'http:'].includes(url.protocol)) throw new Error('链接格式不正确。'); await shell.openExternal(url.href); return {}; },
  saveText: async value => {
    if (typeof value.content !== 'string' || value.content.length > 15_000_000) throw new Error('文件内容无效或过大。');
    const result = await dialog.showSaveDialog(mainWindow, { defaultPath: path.basename(value.name) }); if (result.canceled) return { canceled: true };
    await fs.writeFile(result.filePath, value.content, 'utf8'); return { saved: true };
  },
  saveAttachment: async value => { const r = await dialog.showSaveDialog(mainWindow, { defaultPath: path.basename(value.name) }); if (r.canceled) return { canceled: true }; await fs.copyFile(service.attachmentPath(value.id), r.filePath); return { saved: true }; },
  windowAction: action => { if (action === 'minimize') mainWindow.minimize(); if (action === 'maximize') mainWindow.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize(); if (action === 'close') mainWindow.close(); return {}; },
  cancelClose: () => { clearTimeout(closeTimer); return {}; },
  closeReady: () => { clearTimeout(closeTimer); closing = true; mainWindow.close(); return {}; }
};
ipcMain.handle('scientify:request', async (event, { method, value }) => {
  if (event.sender !== mainWindow?.webContents || !Object.hasOwn(handlers, method)) return { error: '操作不可用。' };
  try { return await handlers[method](value); } catch (err) { return { error: friendly(err) }; }
});
async function createWindow() {
  closing = false; service = new Services(path.join(app.getPath('userData'), 'workspace'));
  mainWindow = new BrowserWindow({ width: 1480, height: 940, minWidth: 1040, minHeight: 680, title: 'Scientify', frame: false, backgroundColor: '#fbfbfa', webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.on('will-navigate', event => event.preventDefault());
  mainWindow.on('close', event => {
    if (closing) return; event.preventDefault(); mainWindow.webContents.send('scientify:flush'); clearTimeout(closeTimer);
    closeTimer = setTimeout(async () => { if (!mainWindow) return; const result = await dialog.showMessageBox(mainWindow, { type: 'warning', message: '内容尚未完成保存', detail: '可以继续等待，也可以保留最近一次保存的内容并退出。', buttons: ['继续等待', '退出'], defaultId: 0, cancelId: 0 }); if (result.response === 1) { closing = true; mainWindow.close(); } }, 8000);
  });
  mainWindow.on('closed', () => { clearTimeout(closeTimer); mainWindow = null; });
  await mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
  mainWindow.show();
}
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if(mainWindow){if(mainWindow.isMinimized())mainWindow.restore();mainWindow.show();mainWindow.focus();} });
  app.whenReady().then(createWindow);
}
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
