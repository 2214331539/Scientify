const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { XMLParser } = require('fast-xml-parser');
const exec = promisify(execFile);
const core = () => import('../renderer/core.mjs');
function friendly(e) { return e.name === 'AbortError' ? '操作已取消。' : e.name === 'TimeoutError' || e.killed ? '等待时间较长，请稍后重试。' : e.code === 'ENOENT' ? '未找到所需程序或文件。' : e.message === 'fetch failed' ? '暂时无法连接服务，请检查连接后重试。' : e.message || '操作未完成，请重试。'; }
class Services {
  constructor(directory) { this.directory = directory; this.queue = Promise.resolve(); this.controllers = new Map(); }
  async init() { await fs.mkdir(path.join(this.directory, 'attachments'), { recursive: true }); }
  async load() {
    await this.init();
    try { return { workspace: (await core()).validateWorkspace(JSON.parse(await fs.readFile(path.join(this.directory, 'workspace.json'), 'utf8'))) }; }
    catch (e) { return e.code === 'ENOENT' ? { workspace: null } : { error: '工作区文件未能完整读取。你可以恢复最近一次备份。', recoverable: true }; }
  }
  save(workspace) {
    const snapshot = JSON.stringify(workspace);
    const operation = this.queue.catch(() => {}).then(async () => {
      (await core()).validateWorkspace(JSON.parse(snapshot)); await this.init();
      const target = path.join(this.directory, 'workspace.json'), pending = path.join(this.directory, 'workspace.pending.json');
      await fs.writeFile(pending, snapshot, 'utf8');
      try { await fs.copyFile(target, path.join(this.directory, 'workspace.backup.json')); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      await fs.rename(pending, target); return { saved: true, revision: workspace.revision };
    });
    this.queue = operation; return operation;
  }
  async restoreBackup() {
    const backup = (await core()).validateWorkspace(JSON.parse(await fs.readFile(path.join(this.directory, 'workspace.backup.json'), 'utf8')));
    await fs.copyFile(path.join(this.directory, 'workspace.json'), path.join(this.directory, `workspace-unreadable-${Date.now()}.json`)).catch(() => {});
    await fs.writeFile(path.join(this.directory, 'workspace.json'), JSON.stringify(backup), 'utf8'); return { workspace: backup };
  }
  async preserveLegacy(value) {
    if (!value || value.length > 10_000_000) return {}; JSON.parse(value); await this.init();
    await fs.writeFile(path.join(this.directory, 'previous-workspace.json'), value, { encoding: 'utf8', flag: 'wx' }).catch(e => { if (e.code !== 'EEXIST') throw e; }); return { saved: true };
  }
  async importWorkspace(value) {
    const workspace = (await core()).validateWorkspace(value);
    await this.queue.catch(() => {}); await this.init();
    const backup = `workspace-before-import-${Date.now()}.json`;
    try { await fs.copyFile(path.join(this.directory, 'workspace.json'), path.join(this.directory, backup)); } catch (err) { if (err.code !== 'ENOENT') throw err; }
    workspace.revision = 0; workspace.updatedAt = new Date().toISOString();
    await this.save(workspace); return { workspace, backup };
  }
  attachmentPath(id) { if (!/^[a-f0-9-]{36}$/.test(id)) throw new Error('文件标识无效。'); return path.join(this.directory, 'attachments', id); }
  async importBuffer(name, base64) {
    const bytes = Buffer.from(base64, 'base64'); if (!bytes.length || bytes.length > 50 * 1024 * 1024) throw new Error('请选择不超过 50 MB 的文件。');
    await this.init(); const id = crypto.randomUUID(); await fs.writeFile(this.attachmentPath(id), bytes);
    return { id, name: path.basename(name), size: bytes.length, digest: crypto.createHash('sha256').update(bytes).digest('hex'), importedAt: new Date().toISOString() };
  }
  async importPath(filename) { if ((await fs.stat(filename)).size > 50 * 1024 * 1024) throw new Error('单个文件不能超过 50 MB。'); return this.importBuffer(path.basename(filename), (await fs.readFile(filename)).toString('base64')); }
  async readAttachment(id) { return { base64: (await fs.readFile(this.attachmentPath(id))).toString('base64') }; }
  endpoint(value) {
    let url; try { url = new URL(value); } catch { throw new Error('请输入有效的本地服务地址。'); }
    if (!['http:', 'https:'].includes(url.protocol) || !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname) || url.username || url.password) throw new Error('请输入本机 Ollama 地址，例如 http://127.0.0.1:11434。');
    return url.origin;
  }
  async models(endpoint) {
    const origin = this.endpoint(endpoint);
    try { const response = await fetch(origin + '/api/tags', { signal: AbortSignal.timeout(8000) }); if (!response.ok) throw new Error(); const value = await response.json(); if (!Array.isArray(value.models)) throw new Error(); return { models: value.models.map(m => m.name).filter(Boolean) }; }
    catch { throw new Error('无法连接 Ollama。请确认它正在运行，并检查服务地址。'); }
  }
  async chat({ endpoint, model, messages, requestId }) {
    if (typeof model !== 'string' || !model.trim() || !Array.isArray(messages)) throw new Error('请选择可用的模型。');
    const controller = new AbortController(); this.controllers.set(requestId, controller); const timer = setTimeout(() => controller.abort(), 180000);
    try {
      const response = await fetch(this.endpoint(endpoint) + '/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model, messages, stream: false }), signal: controller.signal });
      if (!response.ok) throw new Error('模型暂时无法回答，请确认模型可用后重试。');
      const result = await response.json(); if (!result.message?.content?.trim()) throw new Error('模型没有返回内容，请重试。'); return { content: result.message.content };
    } finally { clearTimeout(timer); this.controllers.delete(requestId); }
  }
  cancelChat(id) { this.controllers.get(id)?.abort(); return { canceled: true }; }
  async papers({ keyword, category = '' }) {
    if (typeof keyword !== 'string' || !keyword.trim()) throw new Error('请填写订阅关键词。');
    const term = keyword.trim().slice(0, 150).replace(/["\\]/g, '');
    const query = `all:"${term}"` + (/^[a-zA-Z-]+\.[a-zA-Z-]+$/.test(category) ? ` AND cat:${category}` : '');
    const url = new URL('https://export.arxiv.org/api/query'); url.search = new URLSearchParams({ search_query: query, start: '0', max_results: '20', sortBy: 'submittedDate', sortOrder: 'descending' });
    const response = await fetch(url, { signal: AbortSignal.timeout(25000), headers: { 'User-Agent': 'Scientify/0.2' } });
    if (!response.ok) throw new Error(response.status === 429 ? 'arXiv 请求较多，请稍后更新。' : '暂时无法获取论文，请重试。');
    const document = new XMLParser({ ignoreAttributes: false }).parse(await response.text());
    const entries = document.feed?.entry ? [document.feed.entry].flat() : [];
    return { papers: entries.filter(e => typeof e.id === 'string' && e.id.includes('/abs/')).map(item => {
      const arxivId = item.id.split('/abs/')[1];
      return { arxivId, title: String(item.title).replace(/\s+/g, ' ').trim(), authors: [item.author || []].flat().map(a => a.name).join(', '), abstract: String(item.summary || '').replace(/\s+/g, ' ').trim(), published: item.published, url: `https://arxiv.org/abs/${arxivId}`, source: 'arXiv', category: [item.category || []].flat().map(x => x['@_term']).filter(Boolean).join(', ') };
    }) };
  }
  async downloadPaper(id) {
    if (!/^\d{4}\.\d{4,5}(v\d+)?$/.test(id)) throw new Error('请下载 PDF 后手动导入此论文。');
    const response = await fetch(`https://arxiv.org/pdf/${id}`, { signal: AbortSignal.timeout(45000) }); if (!response.ok) throw new Error('PDF 下载失败，可稍后重试或手动导入。');
    const bytes = Buffer.from(await response.arrayBuffer()); if (!bytes.subarray(0, 100).toString().includes('%PDF-')) throw new Error('来源没有返回有效 PDF。');
    return this.importBuffer(id + '.pdf', bytes.toString('base64'));
  }
  async git(repo, args) {
    if (!repo || typeof repo !== 'string' || !path.isAbsolute(repo)) throw new Error('请先选择本地 Git 仓库。');
    try { return (await exec('git', ['--literal-pathspecs', '-C', repo, ...args], { windowsHide: true, timeout: 15000, maxBuffer: 4_000_000 })).stdout; }
    catch (e) { throw new Error(e.code === 'ENOENT' ? '没有找到 Git，请先安装 Git。' : String(e.stderr || '').includes('not a git repository') ? '所选目录不是 Git 仓库。' : String(e.stderr || e.message).trim().slice(0, 600)); }
  }
  async repoStatus(repo) {
    await this.git(repo, ['rev-parse', '--show-toplevel']);
    const [branch, changes, log] = await Promise.all([this.git(repo, ['branch', '--show-current']), this.git(repo, ['status', '--porcelain=v1', '-z']), this.git(repo, ['log', '-20', '--format=%H%x1f%h%x1f%s%x1f%an%x1f%aI']).catch(() => '')]);
    const parts = changes.split('\0'), files = [];
    for (let i = 0; i < parts.length; i++) { const line = parts[i]; if (!line) continue; const status = line.slice(0, 2); files.push({ status, name: line.slice(3) }); if (/[RC]/.test(status)) i++; }
    return { branch: branch.trim() || 'HEAD', files, commits: log.trim().split('\n').filter(Boolean).map(line => { const [hash, short, title, author, date] = line.split('\x1f'); return { hash, short, title, author, date }; }) };
  }
  async diff({ repo, hash, file }) {
    if (hash) { if (!/^[a-f0-9]{7,40}$/.test(hash)) throw new Error('提交标识无效。'); return { text: await this.git(repo, ['show', '--format=fuller', '--stat', '--patch', hash]) }; }
    const status = await this.repoStatus(repo), change = status.files.find(x => x.name === file); if (!change) throw new Error('文件已变化，请刷新仓库。');
    return { text: change.status === '??' ? '新文件尚未加入版本管理。提交后可查看版本差异。' : await this.git(repo, ['diff', 'HEAD', '--', file]) };
  }
  async commit({ repo, files, message }) {
    if (!message?.trim() || !Array.isArray(files) || !files.length) throw new Error('请选择文件并填写提交说明。');
    const status = await this.repoStatus(repo); if (files.some(file => !status.files.some(x => x.name === file))) throw new Error('文件已变化，请刷新后重新选择。');
    await this.git(repo, ['add', '--', ...files]); await this.git(repo, ['commit', '--only', '-m', message.trim(), '--', ...files]); return this.repoStatus(repo);
  }
  async texStatus() { try { await exec('xelatex', ['--version'], { windowsHide: true, timeout: 5000 }); return { available: true }; } catch { return { available: false }; } }
  async compile(source) {
    if (typeof source !== 'string' || source.length > 1_000_000) throw new Error('源码内容无效或过长。');
    if (!(await this.texStatus()).available) throw new Error('未找到 XeLaTeX。安装 TeX Live 或 MiKTeX 后可编译，也可以先保存源码。');
    const folder = path.join(this.directory, 'exports', crypto.randomUUID()); await fs.mkdir(folder, { recursive: true }); await fs.writeFile(path.join(folder, 'main.tex'), source, 'utf8');
    try { const result = await exec('xelatex', ['-no-shell-escape', '-interaction=nonstopmode', '-halt-on-error', 'main.tex'], { cwd: folder, windowsHide: true, timeout: 45000, maxBuffer: 2_000_000 }); return { success: true, log: result.stdout, attachment: await this.importPath(path.join(folder, 'main.pdf')) }; }
    catch (e) { return { success: false, log: String(e.stdout || e.stderr || e.message).slice(-30000) }; }
  }
}
module.exports = { Services, friendly };
