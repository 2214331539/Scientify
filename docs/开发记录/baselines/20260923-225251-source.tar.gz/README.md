# Scientify · Tauri 迁移预览

本地科研工作台。项目正在从 Electron + 原生 JavaScript 迁移到 **Rust / Tauri 2 + React 19 + TypeScript + Vite 6 + Zustand 5 + Tailwind CSS 4**。

当前交付为 **M1：桌面基础、项目管理与数据持久化**。研究记录编辑、PDF 阅读、arXiv、AI 助手、实验编辑、Git 和 LaTeX 尚未完成新版本迁移。旧数据中的这些内容会保留，原实现与回归测试仍在仓库中。

## 启动新应用

Windows 需要 Node.js 22.14–24、pnpm 10.11.0、Rust stable、MSVC C++ Build Tools 与 WebView2 Runtime。

```powershell
cd F:\Project\Scientify\Scientify
pnpm install --frozen-lockfile
pnpm start
```

双击 `Scientify.cmd` 也会启动 Tauri 开发应用。首次编译 Rust 需要几分钟。Vite 固定使用 `127.0.0.1:1420`。

`pnpm dev` 仅启动网页资源服务器；在浏览器直接访问时不会访问本地数据，也不会伪装成已连接桌面后端。

## M1 已迁移能力

- React 个人 / 团队空间、团队信息与个人偏好。
- 项目创建、编辑、目录关联、跨空间转移、收藏、归档 / 恢复、搜索、排序、网格 / 列表。
- 项目概览，显示已有研究记录、文献、实验和待办。
- Rust schema 3 校验、单写入者锁、revision 冲突保护、原子保存、最近备份、损坏恢复。
- 原生 JSON 导入 / 导出与整个 Electron 工作区复制迁移。
- 未保存表单退出确认、保存失败保留草稿、浅色 / 深色主题。

## 数据目录与旧数据迁移

- 开发版：本仓库 `.tauri-data/workspace/`，与生产数据隔离。
- 正式版：`%APPDATA%/com.scientify.desktop/workspace/`。
- Electron 旧目录：`%APPDATA%/scientify-desktop-sample/workspace/`。
- debug 可设置 `SCIENTIFY_DATA_DIR` 为绝对路径来隔离验收数据；正式版忽略此变量。

关闭旧应用，在新应用的“数据与备份”中选择“复制旧数据”。该操作只支持空的新目录，完整复制工作区及附件，不改动旧目录。复制完成后两版数据各自独立，不会同步。源目录如含符号链接或目录联接，迁移会拒绝并保留原文件。

JSON 导出仅包含记录与附件索引。跨电脑迁移应在应用关闭后备份整个 workspace 目录。导入前会生成 `workspace-before-import-*.json`；恢复时保留 `workspace-unreadable-*.json`。请勿手动删除备份或 `previous-workspace.json`。

## 验证与构建

```powershell
pnpm check
pnpm test
pnpm test:legacy
pnpm legacy:check
cargo fmt --all --check
cargo check --workspace --locked
cargo test --workspace --locked
cargo clippy --workspace --all-targets --locked -- -D warnings
pnpm build
pnpm tauri build --debug --no-bundle
```

以上 debug 构建将静态资源嵌入 `target/debug/scientify.exe`，可离线运行。正式安装包命令：`pnpm tauri build --bundles nsis`。签名与自动更新尚未配置，M1 不作为全功能正式发布。

## 工程结构

- `src/`：React 页面、领域类型、Zustand store、Tauri 调用适配器。
- `crates/scientify-core/`：无 Tauri 依赖的校验与存储，可独立测试。
- `src-tauri/`：命令权限、桌面生命周期、原生对话框和打包配置。
- `electron/`、`renderer/`、`preview.cjs`：过渡期保留的旧应用，不参与新前端构建。
- `package-lock.json`：旧 npm 锁文件，仅用于历史基线；新版本只使用 `pnpm-lock.yaml`。

旧应用可通过 `pnpm legacy:start` 启动，旧文档见 [README.electron.md](README.electron.md)。若 Electron 可执行文件缺失，可执行 `node node_modules/electron/install.js` 恢复旧运行环境。不要让两个版本共用同一个数据目录。

确定的技术方案与阶段进度位于仓库上一级：

- [Scientify-Tauri-React迁移技术方案](../docs/技术方案/Scientify-Tauri-React迁移技术方案.md)
- [迁移实施记录](../docs/技术方案/迁移实施记录.md)
