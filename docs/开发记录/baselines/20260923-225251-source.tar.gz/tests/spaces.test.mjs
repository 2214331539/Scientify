import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyWorkspace,validateWorkspace} from '../renderer/core.mjs';
import {spaceProjects,spaceShell,spacePage,projectSidebar} from '../renderer/spaces.mjs';

function fixture(){const d=emptyWorkspace();d.teams=[{id:'team-a',name:'计算生物组',color:'#657b71'},{id:'team-b',name:'社会计算组',color:'#7086aa'}];d.projects=[
  {id:'personal-a',name:'个人研究',question:'泛化',createdAt:'2026-09-01',updatedAt:'2026-09-03',space:'personal'},
  {id:'team-project-a',name:'细胞表征',question:'迁移学习',field:'计算生物学',createdAt:'2026-09-01',updatedAt:'2026-09-02',space:'team-a',favorite:true},
  {id:'team-project-b',name:'细胞图谱',question:'批次效应',createdAt:'2026-09-01',updatedAt:'2026-09-04',space:'team-a'},
  {id:'archived-a',name:'旧课题',question:'',createdAt:'2026-08-01',space:'team-a',archived:true},
  {id:'team-other',name:'社会计算',question:'',createdAt:'2026-09-01',space:'team-b'}
];return d;}
test('previous workspace projects migrate to personal without losing records',()=>{const old=fixture();delete old.teams;old.projects=[old.projects[0]];delete old.projects[0].space;const next=validateWorkspace(old);assert.equal(next.projects[0].space,'personal');assert.deepEqual(next.teams,[]);assert.equal(next.projects[0].question,'泛化');assert.equal(old.projects[0].space,undefined);});
test('spaces isolate projects and retain filters, search and ordering',()=>{const d=fixture();assert.deepEqual(spaceProjects(d,'personal').map(x=>x.id),['personal-a']);assert.deepEqual(spaceProjects(d,'team-a').map(x=>x.id),['team-project-b','team-project-a']);assert.deepEqual(spaceProjects(d,'team-a',{filter:'favorite'}).map(x=>x.id),['team-project-a']);assert.deepEqual(spaceProjects(d,'team-a',{filter:'archived'}).map(x=>x.id),['archived-a']);assert.deepEqual(spaceProjects(d,'team-a',{query:'批次'}).map(x=>x.id),['team-project-b']);assert.equal(d.projects.length,5);});
test('unknown project ownership and duplicate teams are rejected',()=>{const d=fixture();d.projects[0].space='missing';assert.throws(()=>validateWorkspace(d),/所属团队/);d.projects[0].space='personal';d.teams.push({...d.teams[0]});assert.throws(()=>validateWorkspace(d),/团队信息/);});
test('manager and editor have distinct navigation surfaces',()=>{const data=fixture(),c={data,ui:{projectQuery:'',projectFilter:'all',projectSort:'updated',projectView:'grid',projectId:'team-project-a'},route:{type:'home'},records:()=>[],runs:()=>[],project:id=>data.projects.find(x=>x.id===id)};const shell=spaceShell(c);assert.equal(shell.tabs,'');assert.match(shell.sidebar,/个人信息/);assert.match(shell.sidebar,/团队工作空间/);assert.ok(!shell.sidebar.includes('研究工作区'));const page=spacePage(c);assert.match(page,/个人研究/);assert.ok(!page.includes('细胞表征'));c.route={type:'research'};const editor=projectSidebar(c);assert.match(editor,/leave-project/);assert.match(editor,/细胞表征/);assert.match(editor,/研究工作区/);assert.ok(!editor.includes('社会计算'));
});
