import { useEffect, useId, useRef, type ReactNode } from 'react';

export function Modal({ title, children, onClose, busy = false, dirty = false }: {
  title: string; children: ReactNode; onClose(): void; busy?: boolean; dirty?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const id = useId();
  useEffect(() => { const dialog = ref.current!; dialog.showModal(); return () => dialog.close(); }, []);
  function close() {
    if (!busy && (!dirty || window.confirm('放弃尚未保存的修改？'))) onClose();
  }
  return <dialog ref={ref} aria-labelledby={id} onCancel={event => { event.preventDefault(); close(); }}>
    <header className="dialog-heading"><h2 id={id}>{title}</h2><button type="button" className="icon-button" onClick={close} disabled={busy} aria-label="关闭弹窗">×</button></header>
    {children}
  </dialog>;
}
