import { useEffect, useState, type FormEvent } from 'react';
import { useStore } from 'zustand';
import { Modal } from '../../components/Modal';
import type { Project, Team } from '../../domain/workspace';
import type { WorkspaceStore } from '../../stores/workspace';

export function ProjectForm({ project, space, store, onClose }: { project?: Project; space: string; store: WorkspaceStore; onClose(): void }) {
  const data = useStore(store, s => s.data)!;
  const busy = useStore(store, s => s.busy);
  const error = useStore(store, s => s.error);
  const [draft, setDraft] = useState(() => ({
    name: project?.name ?? '', question: project?.question ?? '', field: project?.field ?? '',
    space: project?.space ?? space, path: project?.path ?? '', repo: project?.repo ?? '',
    color: project?.color ?? '#657b71',
  }));
  const [dirty, setDirty] = useState(false);
  useEffect(() => { store.getState().setDirty(dirty); return () => store.getState().setDirty(false); }, [dirty, store]);
  function field(key: keyof typeof draft, value: string) { setDraft(d => ({ ...d, [key]: value })); setDirty(true); }
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!draft.name.trim()) return;
    const saved = await store.getState().update(workspace => {
      const timestamp = new Date().toISOString();
      if (project) {
        const target = workspace.projects.find(p => p.id === project.id);
        if (!target) throw new Error('项目不存在，请重新载入。');
        Object.assign(target, draft, { name: draft.name.trim(), updatedAt: timestamp });
      } else {
        workspace.projects.push({ ...draft, name: draft.name.trim(), id: crypto.randomUUID(), createdAt: timestamp, updatedAt: timestamp });
      }
    });
    if (saved) onClose();
  }
  return <Modal title={project ? '编辑项目' : '新建科研项目'} onClose={onClose} busy={busy} dirty={dirty}>
    <form onSubmit={submit} className="form-grid">
      <label>项目名称<input disabled={busy} autoFocus required maxLength={160} value={draft.name} onChange={e => field('name', e.target.value)} placeholder="例如：小样本学习中的表征泛化" /></label>
      <label>研究问题<textarea disabled={busy} rows={3} value={draft.question} onChange={e => field('question', e.target.value)} placeholder="这个项目希望回答什么问题？" /></label>
      <div className="form-pair"><label>所属空间<select disabled={busy} value={draft.space} onChange={e => field('space', e.target.value)}><option value="personal">我的工作空间</option>{data.teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
        <label>研究方向<input disabled={busy} value={draft.field} onChange={e => field('field', e.target.value)} placeholder="研究领域或关键词" /></label></div>
      <label>项目目录<div className="input-action"><input disabled={busy} readOnly value={draft.path} placeholder="尚未关联本地目录" /><button type="button" disabled={busy} onClick={async () => { const path = await store.getState().chooseDirectory(); if (path) field('path', path); }}>选择目录</button><button type="button" disabled={busy || !draft.path} onClick={() => field('path', '')}>清除</button></div></label>
      <label>Git 仓库目录<div className="input-action"><input disabled={busy} readOnly value={draft.repo} placeholder="可单独关联 Git 仓库" /><button type="button" disabled={busy} onClick={async () => { const path = await store.getState().chooseDirectory(); if (path) field('repo', path); }}>选择仓库</button><button type="button" disabled={busy || !draft.repo} onClick={() => field('repo', '')}>清除</button></div></label>
      <label className="color-label">项目颜色<input disabled={busy} type="color" value={draft.color} onChange={e => field('color', e.target.value)} /></label>
      {error ? <p role="alert" className="error-text">{error}</p> : null}
      <footer className="dialog-footer"><span className="muted">保存在本机工作区</span><button className="primary" disabled={busy || !draft.name.trim()} type="submit">{busy ? '正在保存…' : '保存项目'}</button></footer>
    </form>
  </Modal>;
}

export function TeamForm({ team, store, onClose }: { team?: Team; store: WorkspaceStore; onClose(): void }) {
  const [name, setName] = useState(team?.name ?? '');
  const [description, setDescription] = useState(team?.description ?? '');
  const dirty = name !== (team?.name ?? '') || description !== (team?.description ?? '');
  const busy = useStore(store, s => s.busy);
  const error = useStore(store, s => s.error);
  useEffect(() => { store.getState().setDirty(dirty); return () => store.getState().setDirty(false); }, [dirty, store]);
  return <Modal title={team ? '团队信息' : '创建团队空间'} busy={busy} dirty={dirty} onClose={onClose}>
    <form className="form-grid" onSubmit={async e => {
      e.preventDefault();
      if (!name.trim()) return;
      if (await store.getState().update(d => {
        if (team) Object.assign(d.teams.find(t => t.id === team.id)!, { name: name.trim(), description });
        else d.teams.push({ id: crypto.randomUUID(), name: name.trim(), description, color: '#657b71' });
      })) onClose();
    }}>
      <label>团队名称<input disabled={busy} autoFocus required maxLength={100} value={name} onChange={e => setName(e.target.value)} /></label>
      <label>团队介绍<textarea disabled={busy} rows={4} value={description} onChange={e => setDescription(e.target.value)} /></label>
      <p className="muted">团队空间用于本机项目分类，成员邀请与在线协作尚未开放。</p>
      {error ? <p role="alert" className="error-text">{error}</p> : null}
      <footer className="dialog-footer"><span /><button type="submit" className="primary" disabled={busy || !name.trim()}>{busy ? '正在保存…' : '保存团队'}</button></footer>
    </form>
  </Modal>;
}
