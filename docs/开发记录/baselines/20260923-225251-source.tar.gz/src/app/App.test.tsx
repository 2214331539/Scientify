import { afterEach, beforeAll, expect, it, vi } from 'vitest';
import { act, cleanup, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { emptyWorkspace, type Workspace } from '../domain/workspace';
import { createWorkspaceStore } from '../stores/workspace';
import type { WorkspaceBackend } from '../platform/desktop';
import { App } from './App';

beforeAll(() => {
  window.matchMedia = vi.fn().mockReturnValue({ matches: false, addEventListener: vi.fn(), removeEventListener: vi.fn() });
  HTMLDialogElement.prototype.showModal = function () { this.setAttribute('open', ''); };
  HTMLDialogElement.prototype.close = function () { this.removeAttribute('open'); };
});

it('locks form fields while persistence is pending so late input cannot be lost', async () => {
  let complete!: () => void;
  const adapter: WorkspaceBackend = {
    load: async () => ({ workspace: emptyWorkspace(), directory: 'test/data', legacyAvailable: false }),
    save: value => new Promise(resolve => { complete = () => resolve(value); }),
    restore: async () => emptyWorkspace(), migrateLegacy: async () => emptyWorkspace(),
    importWorkspace: async () => null, exportWorkspace: async () => true, chooseDirectory: async () => null,
  };
  const store = createWorkspaceStore(adapter);
  const user = userEvent.setup();
  render(<App store={store} />);
  await screen.findByText('从你的第一个研究问题开始');
  await user.click(screen.getAllByRole('button', { name: /新建项目/ })[0]);
  await user.type(screen.getByLabelText('项目名称'), '延迟保存');
  await user.click(screen.getByRole('button', { name: '保存项目' }));
  expect((screen.getByLabelText('项目名称') as HTMLInputElement).disabled).toBe(true);
  expect((screen.getByLabelText('研究问题') as HTMLTextAreaElement).disabled).toBe(true);
  expect((screen.getByRole('button', { name: '关闭弹窗' }) as HTMLButtonElement).disabled).toBe(true);
  await act(async () => complete());
  await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  expect(store.getState().data?.projects[0].name).toBe('延迟保存');
});
afterEach(cleanup);

it('creates a project, retains failed form edits, and retries into the real store', async () => {
  let disk: Workspace | null = null;
  const save = vi.fn(async (value: Workspace) => { disk = structuredClone(value); return value; });
  save.mockRejectedValueOnce(new Error('测试写入失败'));
  const adapter: WorkspaceBackend = {
    load: async () => ({ workspace: disk, directory: 'test/data', legacyAvailable: false }),
    save, restore: async () => emptyWorkspace(), migrateLegacy: async () => emptyWorkspace(),
    importWorkspace: async () => null, exportWorkspace: async () => true, chooseDirectory: async () => 'F:\\research',
  };
  const store = createWorkspaceStore(adapter);
  const user = userEvent.setup();
  render(<App store={store} />);
  await screen.findByText('从你的第一个研究问题开始');
  await user.click(screen.getAllByRole('button', { name: /新建项目/ })[0]);
  await user.type(screen.getByLabelText('项目名称'), '迁移验证项目');
  await user.type(screen.getByLabelText('研究问题'), '数据是否完整？');
  await user.click(screen.getByRole('button', { name: '保存项目' }));
  await screen.findByText('测试写入失败');
  expect((screen.getByLabelText('项目名称') as HTMLInputElement).value).toBe('迁移验证项目');
  expect(store.getState().data?.projects).toHaveLength(0);
  expect(store.getState().dirty).toBe(true);
  await user.click(screen.getByRole('button', { name: '保存项目' }));
  await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull());
  expect(store.getState().data?.projects[0].question).toBe('数据是否完整？');
  expect(store.getState().dirty).toBe(false);
  await user.click(screen.getByRole('button', { name: '收藏 迁移验证项目' }));
  await waitFor(() => expect(store.getState().data?.projects[0].favorite).toBe(true));
  await user.click(screen.getByRole('button', { name: '归档' }));
  await user.click(screen.getByRole('button', { name: '已归档' }));
  await screen.findByRole('button', { name: '恢复' });
});
