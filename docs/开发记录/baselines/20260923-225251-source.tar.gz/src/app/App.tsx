import { useEffect, useState, type CSSProperties } from 'react';
import { useStore } from 'zustand';
import { isTauri } from '@tauri-apps/api/core';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { Modal } from '../components/Modal';
import { ProjectForm, TeamForm } from '../features/projects/ProjectForm';
import { selectProjects, type Project, type ProjectFilter, type Team, type Workspace } from '../domain/workspace';
import { workspaceStore, type WorkspaceStore } from '../stores/workspace';

type Dialog = { kind: 'project'; project?: Project } | { kind: 'team'; team?: Team } | { kind: 'data' } | { kind: 'profile' } | null;

function useCloseProtection(store: WorkspaceStore) {
  useEffect(() => {
    function beforeUnload(event: BeforeUnloadEvent) {
      if (store.getState().dirty || store.getState().busy) { event.preventDefault(); event.returnValue = ''; }
    }
    window.addEventListener('beforeunload', beforeUnload);
    let disposed = false;
    let cleanup: (() => void) | undefined;
    if (isTauri()) {
      void getCurrentWindow().onCloseRequested(async event => {
        event.preventDefault();
        const { dirty, busy } = store.getState();
        if (busy) return;
        if (!dirty || window.confirm('尚有未保存的表单内容，放弃修改并退出？')) {
          await getCurrentWindow().destroy();
        }
      }).then(unlisten => { if (disposed) unlisten(); else cleanup = unlisten; });
    }
    return () => { disposed = true; cleanup?.(); window.removeEventListener('beforeunload', beforeUnload); };
  }, [store]);
}

export function App({ store = workspaceStore }: { store?: WorkspaceStore }) {
  const data = useStore(store, s => s.data);
  const phase = useStore(store, s => s.phase);
  const busy = useStore(store, s => s.busy);
  const error = useStore(store, s => s.error);
  const notice = useStore(store, s => s.notice);
  const directory = useStore(store, s => s.directory);
  const [space, setSpace] = useState('personal');
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<ProjectFilter>('all');
  const [sort, setSort] = useState('updated');
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [dialog, setDialog] = useState<Dialog>(null);
  useCloseProtection(store);
  useEffect(() => { void store.getState().load(); }, [store]);
  useEffect(() => {
    if (data && space !== 'personal' && !data.teams.some(t => t.id === space)) setSpace('personal');
    if (data && activeProject && !data.projects.some(p => p.id === activeProject)) setActiveProject(null);
  }, [data, space, activeProject]);
  useEffect(() => {
    const media = matchMedia('(prefers-color-scheme: dark)');
    const apply = () => document.documentElement.classList.toggle('dark', data?.settings.theme === 'dark' || (data?.settings.theme === 'system' && media.matches));
    apply(); media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, [data?.settings.theme]);
  function openDialog(next: Dialog) { store.getState().clearMessage(); setDialog(next); }
  function changeSpace(id: string) { setSpace(id); setActiveProject(null); setQuery(''); setFilter('all'); }
  const project = data?.projects.find(p => p.id === activeProject);
  const team = data?.teams.find(t => t.id === space);
  const title = space === 'personal' ? '我的工作空间' : team?.name ?? '团队空间';
  const projects = data ? selectProjects(data, space, query, filter, sort) : [];

  async function toggle(project: Project, key: 'favorite' | 'archived') {
    await store.getState().update(draft => {
      const target = draft.projects.find(p => p.id === project.id)!;
      target[key] = !target[key]; target.updatedAt = new Date().toISOString();
    });
  }

  return <div className="app-shell">
    <aside className="sidebar" aria-label="工作区导航">
      <a className="brand" href="#" onClick={e => { e.preventDefault(); changeSpace('personal'); }}><span className="brand-mark">S</span><span>Scientify<span className="brand-sub">研究，从一个问题开始</span></span></a>
      <button className="identity" onClick={() => openDialog({ kind: 'profile' })} disabled={!data || busy}><span className="avatar">{data?.settings.name?.slice(0, 1) || '研'}</span><span>{data?.settings.name || '我的研究空间'}<small>本地工作区</small></span><span className="muted">⌄</span></button>
      <p className="section-label">个人</p>
      <button className={space === 'personal' ? 'nav-item active' : 'nav-item'} onClick={() => changeSpace('personal')}><span aria-hidden="true">▦</span>我的工作空间<span className="count">{data?.projects.filter(p => p.space === 'personal' && !p.archived).length ?? 0}</span></button>
      <div className="sidebar-section-heading"><p className="section-label">团队工作空间</p><button className="icon-button" aria-label="创建团队空间" disabled={!data || busy} onClick={() => openDialog({ kind: 'team' })}>＋</button></div>
      {data?.teams.map(t => <button className={space === t.id ? 'nav-item active' : 'nav-item'} key={t.id} onClick={() => changeSpace(t.id)}><span className="team-dot" style={{ background: t.color }} />{t.name}</button>)}
      {!data?.teams.length ? <p className="sidebar-hint">为课题组创建独立空间，<br />按团队整理科研项目。</p> : null}
      <div className="sidebar-bottom"><div className="local-note"><span className="status-dot" />数据保存在本机</div><button className="nav-item" onClick={() => openDialog({ kind: 'data' })}><span aria-hidden="true">⚙</span><span>数据与备份</span></button><p className="version">Scientify 0.3 · 迁移预览</p></div>
    </aside>

    <section className="main-shell">
      <header className="topbar"><div className="breadcrumbs"><button className="text-button" onClick={() => setActiveProject(null)}>{title}</button>{project ? <><span>/</span><span>{project.name}</span></> : null}</div><span className="save-indicator"><span className={error ? 'status-dot error-dot' : 'status-dot'} />{busy ? '正在保存…' : error ? '操作未完成' : '本地工作区'}</span></header>
      <main>
        {phase === 'idle' || phase === 'loading' ? <div className="empty-state"><span className="empty-symbol">S</span><h1>正在打开工作区</h1><p>读取本机的项目与研究资料…</p></div> : phase === 'error' || !data ?
          <div className="empty-state"><span className="empty-symbol">!</span><h1>工作区未能载入</h1><p role="alert">{error}</p><div className="button-row"><button onClick={() => void store.getState().load()} disabled={busy}>重新载入</button><button onClick={() => { if (window.confirm('恢复最近一次备份？当前主文件将另存保留。')) void store.getState().replace('restore'); }} disabled={busy}>恢复最近备份</button></div><p className="muted">如果正在浏览器中预览，请使用 pnpm start 启动桌面应用。</p></div> :
          project ? <ProjectOverview data={data} project={project} onBack={() => setActiveProject(null)} onEdit={() => openDialog({ kind: 'project', project })} /> :
          <>
            <section className="page-heading"><div><p className="eyebrow">RESEARCH WORKSPACE</p><h1>{title}</h1><p className="page-description">把问题、资料与实验放在一起，让每一步探索都有迹可循。</p></div><div className="button-row">{team ? <button onClick={() => openDialog({ kind: 'team', team })} disabled={busy}>团队信息</button> : null}<button className="primary" onClick={() => openDialog({ kind: 'project' })} disabled={busy}><span aria-hidden="true">＋</span> 新建项目</button></div></section>
            <div className="migration-note"><span className="note-tag">迁移进展</span><p>项目管理与数据备份已迁入新版本。研究记录、文献、实验和助手正在迁移，已有资料会完整保留。</p><button className="text-button" onClick={() => openDialog({ kind: 'data' })}>查看数据</button></div>
            <div className="project-toolbar"><div className="filter-tabs" aria-label="项目筛选">{([['all', '全部项目'], ['favorite', '已收藏'], ['archived', '已归档']] as const).map(([key, name]) => <button key={key} aria-pressed={filter === key} className={filter === key ? 'selected' : ''} onClick={() => setFilter(key)}>{name}</button>)}</div>
              <div className="toolbar-actions"><input className="search" type="search" aria-label="搜索项目" placeholder="搜索项目、方向或问题…" value={query} onChange={e => setQuery(e.target.value)} /><select aria-label="项目排序" value={sort} onChange={e => setSort(e.target.value)}><option value="updated">最近更新</option><option value="name">名称排序</option></select><div className="view-switch"><button aria-label="网格视图" aria-pressed={view === 'grid'} onClick={() => setView('grid')}>▦</button><button aria-label="列表视图" aria-pressed={view === 'list'} onClick={() => setView('list')}>☷</button></div></div></div>
            <div className="result-count">{projects.length} 个项目</div>
            {projects.length ? <div className={view === 'grid' ? 'project-grid' : 'project-list'}>{projects.map(p => <article className="project-card" key={p.id} style={{ '--project-color': p.color || '#657b71' } as CSSProperties}>
              <div className="card-top"><span className="project-glyph" aria-hidden="true">▱</span><span className="project-field">{p.field || '科研项目'}</span><button className={p.favorite ? 'icon-button favorite' : 'icon-button'} disabled={busy} aria-label={p.favorite ? '取消收藏 ' + p.name : '收藏 ' + p.name} aria-pressed={Boolean(p.favorite)} onClick={() => void toggle(p, 'favorite')}>{p.favorite ? '★' : '☆'}</button></div>
              <button className="project-open" onClick={() => setActiveProject(p.id)}><h2>{p.name}</h2><p>{p.question || '还没有填写研究问题。编辑项目，记录探索的起点。'}</p></button>
              <div className="project-stats"><span>{data.records.filter(r => r.project === p.id).length} 研究记录</span><span>{data.papers.filter(r => r.projects.includes(p.id)).length} 篇文献</span></div>
              <footer className="card-footer"><span>{dateLabel(p.updatedAt || p.createdAt)}</span><div><button className="text-button" disabled={busy} onClick={() => openDialog({ kind: 'project', project: p })}>编辑</button><button className="text-button" disabled={busy} onClick={() => void toggle(p, 'archived')}>{p.archived ? '恢复' : '归档'}</button></div></footer>
            </article>)}</div> : <div className="empty-state project-empty"><span className="empty-symbol">▱</span><h2>{query || filter !== 'all' ? '没有符合条件的项目' : '从你的第一个研究问题开始'}</h2><p>{query || filter !== 'all' ? '试试其他关键词或筛选条件。' : '创建一个项目，整理研究问题、文献与实验。'}</p>{!query && filter === 'all' ? <button className="primary" disabled={busy} onClick={() => openDialog({ kind: 'project' })}>＋ 新建项目</button> : <button onClick={() => { setQuery(''); setFilter('all'); }}>清除筛选</button>}</div>}
          </>}
      </main>
      <footer className="statusbar"><span className="truncate" title={directory}>{directory || '本机数据尚未载入'}</span><span>离线优先 · 研究属于你</span></footer>
    </section>

    {(notice || error) && phase === 'ready' && !dialog ? <div className={error ? 'toast error-text' : 'toast'} role={error ? 'alert' : 'status'}><span>{error || notice}</span><button className="icon-button" aria-label="关闭提示" onClick={() => store.getState().clearMessage()}>×</button></div> : null}
    {dialog?.kind === 'project' ? <ProjectForm store={store} space={space} project={dialog.project} onClose={() => setDialog(null)} /> : null}
    {dialog?.kind === 'team' ? <TeamForm store={store} team={dialog.team} onClose={() => setDialog(null)} /> : null}
    {dialog?.kind === 'data' ? <DataSettings store={store} onClose={() => setDialog(null)} /> : null}
    {dialog?.kind === 'profile' && data ? <Profile store={store} data={data} onClose={() => setDialog(null)} /> : null}
  </div>;
}

function dateLabel(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '尚未记录时间' : date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }) + ' 更新';
}

function ProjectOverview({ data, project, onBack, onEdit }: { data: Workspace; project: Project; onBack(): void; onEdit(): void }) {
  const records = data.records.filter(r => r.project === project.id);
  const tasks = data.tasks.filter(t => t.project === project.id);
  return <>
    <button className="text-button back-link" onClick={onBack}>← 返回项目空间</button>
    <section className="page-heading"><div><p className="eyebrow">{project.field || 'RESEARCH PROJECT'}</p><h1>{project.name}</h1><p className="page-description">{project.question || '尚未填写研究问题'}</p></div><button onClick={onEdit}>编辑项目</button></section>
    <div className="overview-stats">{[['研究记录', records.length], ['关联文献', data.papers.filter(p => p.projects.includes(project.id)).length], ['实验记录', data.runs.filter(r => r.project === project.id).length], ['待办任务', tasks.filter(t => !t.done).length]].map(([label, count]) => <div key={label}><strong>{count}</strong><span>{label}</span></div>)}</div>
    <div className="overview-grid"><section className="overview-panel"><h2>最近研究记录</h2>{records.length ? [...records].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 8).map(r => <div className="record-row" key={r.id}><div><strong>{r.title}</strong><p>{r.type} · {r.status}</p></div><span>{dateLabel(r.updatedAt)}</span></div>) : <p className="muted">这个项目还没有研究记录。</p>}<p className="panel-footnote">记录编辑与状态看板将在下一阶段迁移。</p></section>
      <section className="overview-panel"><h2>项目待办</h2>{tasks.length ? tasks.map(t => <p className={t.done ? 'task completed' : 'task'} key={t.id}><span aria-label={t.done ? '已完成' : '未完成'}>{t.done ? '☑' : '□'}</span>{t.title}</p>) : <p className="muted">暂时没有待办任务。</p>}<h2 className="directory-title">关联目录</h2><p className="path-text">{project.path || '尚未关联项目目录'}</p><p className="path-text">{project.repo ? 'Git：' + project.repo : '尚未关联 Git 仓库'}</p></section></div>
    <div className="migration-note"><span className="note-tag">资料已保留</span><p>文献阅读、实验编辑、AI 助手和 LaTeX 导出尚在迁移中。当前版本可查看资料数量，不会改写这些内容。</p></div>
  </>;
}

function DataSettings({ store, onClose }: { store: WorkspaceStore; onClose(): void }) {
  const state = useStore(store);
  const confirmReplace = (kind: 'restore' | 'migrateLegacy' | 'importWorkspace', text: string) => {
    if (window.confirm(text)) void state.replace(kind);
  };
  return <Modal title="数据与备份" onClose={onClose} busy={state.busy}>
    <div className="form-grid"><p className="muted">工作区记录与附件均保存在本机。开发版与正式版使用独立数据目录。</p><label>当前目录<code className="data-path">{state.directory || '尚未载入'}</code></label>
      <section className="setting-row"><div><h3>迁移 Electron 数据</h3><p>先关闭旧应用。复制整个工作区及附件，保留旧目录。仅支持迁入空的新工作区。</p></div><button disabled={state.busy || !state.legacyAvailable || state.data?.revision !== 0} onClick={() => confirmReplace('migrateLegacy', '请先关闭 Electron 版 Scientify。将复制整个旧工作区到新目录，原数据保持不变。继续迁移？')}>复制旧数据</button></section>
      {!state.legacyAvailable ? <p className="muted">未检测到默认目录中的 Electron 工作区。</p> : null}
      <section className="setting-row"><div><h3>JSON 导入与导出</h3><p>JSON 包含记录与附件索引，不含附件文件。跨电脑迁移需另行复制完整数据目录。</p></div><div className="button-row"><button disabled={state.busy || state.phase !== 'ready'} onClick={() => confirmReplace('importWorkspace', '导入会替换当前记录，并保存导入前备份。JSON 不包含附件二进制。继续选择文件？')}>导入</button><button disabled={state.busy || state.phase !== 'ready'} onClick={() => void state.exportWorkspace()}>导出</button></div></section>
      <section className="setting-row"><div><h3>恢复最近备份</h3><p>恢复上一次保存内容，并另存当前主文件。</p></div><button disabled={state.busy} onClick={() => confirmReplace('restore', '恢复最近一次备份？当前主文件会另存保留。')}>恢复备份</button></section>
      {state.error ? <p role="alert" className="error-text">{state.error}</p> : null}{state.notice ? <p role="status">{state.notice}</p> : null}
    </div>
  </Modal>;
}

function Profile({ store, data, onClose }: { store: WorkspaceStore; data: Workspace; onClose(): void }) {
  const [name, setName] = useState(data.settings.name);
  const [theme, setTheme] = useState(data.settings.theme);
  const busy = useStore(store, s => s.busy);
  const error = useStore(store, s => s.error);
  const dirty = name !== data.settings.name || theme !== data.settings.theme;
  useEffect(() => { store.getState().setDirty(dirty); return () => store.getState().setDirty(false); }, [dirty, store]);
  return <Modal title="个人信息与偏好" busy={busy} dirty={dirty} onClose={onClose}><form className="form-grid" onSubmit={async e => {
    e.preventDefault(); if (await store.getState().update(d => { d.settings.name = name; d.settings.theme = theme; })) onClose();
  }}><label>显示名称<input disabled={busy} autoFocus value={name} maxLength={100} onChange={e => setName(e.target.value)} /></label><label>界面主题<select disabled={busy} value={theme} onChange={e => setTheme(e.target.value)}><option value="system">跟随系统</option><option value="light">浅色</option><option value="dark">深色</option></select></label><p className="muted">这是本地个人资料，无需登录。</p>{error ? <p role="alert" className="error-text">{error}</p> : null}<footer className="dialog-footer"><span /><button type="submit" className="primary" disabled={busy}>{busy ? '正在保存…' : '保存偏好'}</button></footer></form></Modal>;
}
